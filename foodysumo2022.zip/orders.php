<?php

include 'routers.inc.php';
if(!isset($_SESSION['u_name'])){
  redirect('index');
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'includes/head.php';?>

    <title>Orders | FoodySumo.com</title>
  </head>
  <body>
 <?php include 'includes/navbar.php';?>

 <div class="container mt-3">
		<div class="card">
			<div class="card-body">
				<div class="cart-title">
					<h4 class="display-4 card-head text-center text-white">Order History</h4>
					<div class="container mt-3">
						</div>
						<table id="foodtable" class="table table-striped" style="width:100%">
                <?php 
                $uid = $_SESSION['u_id'];

                function delivery_boy($d_id){
                  if($d_id!=0){
                  $delivery_r = "select * from delivery_boy where id='{$d_id}'";
                  global $conn;
                  $d_data = mysqli_query($conn,$delivery_r);
                  $dr_data=mysqli_fetch_assoc($d_data);
                  return $dr_data['name'];
                  }else{
                    return $dr_data = "Not Assigned";
                  }
                  
                }  
                $sql = "select * from orders where user_id='{$uid}' ORDER BY id DESC";
                $fetch = mysqli_query($conn,$sql);
                if(mysqli_num_rows($fetch)){
                  echo '							<thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Dishes</th>
                    <th>Payment</th>
                    <th>Amount</th>
                    <th>Discount</th>
                    <th>Address</th>
                    <th>Rider</th>
                    <th>STATUS</th>
                    <th>Delivered On</th>
                  </tr>
                </thead>
                <tbody>';
                  while($row=mysqli_fetch_assoc($fetch)){
                    echo '
                    
                    <tr>
                        <td>'.$row['id'].'</td>
                        <td>'.$row['name'].'</td>
                        <td>'.$row['product'].'</td>
                        <td>';
                        
                        if($row['method']==1){
                          echo 'COD';
                        }else{
                          echo 'Paid Online';
                        }
                        echo '</td>
                        <td>'.$row['total'].'</td>
                        <td>'.$row['discount'].'</td>
                        <td>'.$row['address'].'</td>
                        <td>';

                        echo delivery_boy($row['rider_id']);echo'</td>
                        
                        <td>';
                        if($row['status']==1){
                          echo '<button type="button" class="btn btn-primary btn-sm" disabled>Preparing</button>';              
                        }elseif($row['status']==2){
                          echo '<button type="button" class="btn btn-info btn-sm" disabled>On the Way</button>';              
                        }elseif($row['status']==3){
                          echo '<button type="button" class="btn btn-success btn-sm" disabled>Delivered</button>';              
                        }
                        echo '</td>
                        <td>'.$row['date'].'</td>

                    </tr>
                    ';
                  }  
                ?>

</tbody>
              <?php 
              }
              else 
              { echo "<h2 class='text-center text-muted my-3'>No Order Found</h2>" ;} 
              ?>
						
                </table>
					</div>
				</div>
			</div>
		</div>
	</div>
  
  <?php

      if(isset($_GET['alert'])=='success'){
        echo alert_success("Your order has been placed successfully");
      }

  ?>

<?php include 'includes/footer.php'?>
    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>