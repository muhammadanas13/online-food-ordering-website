<?php

include 'routers.inc.php';

if(isset($_GET['sortCat']) && isset($_GET['sortid'])){
    $sortid = $_GET['sortid'];
    $sql = "select * from dish,category where dish.category_id=category.id and category.id='$sortid' and dish.status='1'";
    $res = mysqli_query($conn, $sql);
}else{
$sql = "select * from dish,category where dish.category_id=category.id and dish.status='1'";

$res = mysqli_query($conn, $sql);
}
$sqlCat = "select * from category where status='1' order by category asc";
$sqlCate = mysqli_query($conn, $sqlCat);

if(isset($_POST['addtocart'])){
    $_SESSION['cart'][] = array(
        'id' => mt_rand(10000,100000),
        'dish' => $_POST['dish'],
        'qty' => $_POST['qty'],
        'img'=> $_POST['img'],
        'price'=> $_POST['price']
    );
}


// if($_SESSION['cart']){
//     count($_SESSION['cart']);
// }

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'includes/head.php';?>

    <title>Shop | FoodySumo.com</title>
  </head>
  <body>
 <?php include 'includes/navbar.php';?>

<style>

.product-list {
  position: relative;
  padding: 5px 0;
}

.product-list .picture {
  max-width: 400px;
  overflow: hidden;
  height: auto;
  border-radius: 6px;
}

.product-list .label{
    font-weight:normal;    
}

.product-list .picture {
  max-width: 210px;
}

.product-list .picture img {
  width: 100%;
}

.product-list h4 {
  font-size: 20px;
}

.product-list h5 {
  color: #888;
}

.product-list p {
  float: left;
}

.product-list:after {
  height: 1px;
  background: #EEEEEE;
  width: 83.3333%;
  bottom: 0;
  right: 0;
  content: "";
  display: block;
  position: absolute;
}

.product-list .btn-download {
  margin-top: 45px;
}

.btn-info {
  color: #1084FF;
  border-color: #269abc;
}

.btn-round {
  border-width: 1px;
  border-radius: 30px !important;
  opacity: 0.79;
  padding: 9px 18px;
}
.btn {
  border-width: 2px;
  background-color: rgba(0,0,0,0);
  font-weight: 400;
  opacity: 0.8;
  padding: 7px 16px;
}
</style>

<div class="container mt-4 mb-4">
<div class="col-8">
<form method="get">
  <div class="row">
    <div class="col">
      <label> Sort by Category</label>
    </div>
    <div class="col">
    <select class="form-control" name="sortid">
        <option selected>Category</option>
            <?php
            
                while($cat_data=mysqli_fetch_array($sqlCate)){
                echo "<option value=".$cat_data['id'].">".$cat_data['category']."</option>";
             }
            
            ?>
        </select>
    </div>
    <div class="col">
      <input type="submit" name="sortCat" class="btn btn-info btn-md" value="Sort Dishes">
    </div>
    <div class="col"><a href="shop" class="text-danger text-small">Remove Filter</a></div>
  </div>
</form>
</div>
</div>


<?php 

if(mysqli_num_rows($res)>0){

while($row=mysqli_fetch_assoc($res)){

?>

<div class="container">
    <div class="row">
        <div class="product-list">
            <div class="row">
                <div class="col-sm-2">
                    <div class="picture">
                        <img alt="" src="uploads/dish/<?php echo $row['image'];?>">
                    </div>
                </div>
                <div class="col-sm-6">
                    <h4>
                        <?php echo $row['dish'];?>
                        <label class="label label-info text-info">#<?php echo $row['category'];?></label>
                    </h4>
                    <h5> 
                    <i class="fas fa-money-bill"></i>
                        Price : ₹ <?php echo  $row['price'];?>
                    </h5>
                    <p class="description"> <?php echo $row['dish_details'];?></p>    
                </div>
                <div class="col-sm-4">
                <form method="POST" action="">
                    <input type="hidden" value="<?php echo $row['dish']?>" name="dish">
                    <input type="hidden" value="<?php echo $row['image']?>" name="img">
                    <input type="hidden" value="<?php echo $row['price']?>" name="price">

                    <input type="number" class="form-control" style="width:80px;" value="1" name="qty">

                    <button class="btn btn-info btn-download btn-round pull-right makeLoading" type="submit" name="addtocart">
                    <i class="fa fa-shopping-cart"></i> Add to Cart
                    </button>     
                    </form>       
                </div>
            </div>
        </div>
    </div>
</div>
<?php
}
}
else{
    echo "<h2 class='text-center mt-3 mb-3'>No Dish Found</h2>";
}
?>
<?php include 'includes/footer.php'?>
    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>