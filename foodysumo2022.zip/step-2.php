<?php
include 'routers.inc.php';
if(!isset($_SESSION['otp'])){
    redirect('index');
    die();
}
$error="";
$number = $_SESSION['u_mobile'];
$email = $_SESSION['u_email'];
$otp = $_SESSION['otp'];

if(isset($_POST['sendOTP'])){
    $smsChecker = sms_alert($number,"OTP for FoodySumo ",$otp);
}

if(isset($_POST['submit'])){
    $user_otp = mysqli_real_escape_string($conn,$_POST['user_otp']);
    $address = mysqli_real_escape_string($conn,$_POST['address']);
    $city = mysqli_real_escape_string($conn,$_POST['city']);
    $pincode = mysqli_real_escape_string($conn,$_POST['pincode']);
    $state = mysqli_real_escape_string($conn,$_POST['state']);
    $landmark = mysqli_real_escape_string($conn,$_POST['landmark']);
    $type = mysqli_real_escape_string($conn,$_POST['type']);

    $fetchData = "select id,sms_otp from users where email='{$email}'";
    $execFetech = mysqli_query($conn, $fetchData);
    $showData = mysqli_fetch_assoc($execFetech);
    $user_id = $showData['id'];

    if($showData['sms_otp']==$user_otp){
        $sql = "insert into address (user_id,address,city,pincode,state,landmark,type) values('$user_id','$address','$city','$pincode','$state','$landmark','$type')";
        $inCheck = mysqli_query($conn,$sql);
    
        if($inCheck){

            if($showData['token']=='null' & $showData['sms_otp']==0){
                $update = "update users set sms_otp='null',status=1 where email='{$email}'";
                $chkUpdate = mysqli_query($conn,$update);
                if($chkUpdate){
                    unset($_SESSION['otp']);
                    session_destroy();
                    redirect('index?alert=account-created');
                    die();
                }

            }else{
                $update = "update users set sms_otp='null',status=0  where email='{$email}'";
                $chkUpdate = mysqli_query($conn,$update);
                if($chkUpdate){
                    unset($_SESSION['otp']);
                    session_destroy();
                    redirect('index?alert=verify-email');
                    die();
                }
            }
        }

    }else{
        $error = alert_danger("OTP is incorrect.!");
    }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'includes/head.php';?>

    <title>Complete Step 2 for Registration | FoodySumo.com</title>
  </head>
  <body>
 <?php include 'includes/navbar.php';?>

 <div class="container container-vcenter">
        <div class="row d-flex justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                    <h2 class="card-title display-6 text-white text-center rounded py-2 mb-4 card-head">Step 2</h2>
                        <form class="mt-2" method="POST" action="<?php echo $_SERVER['PHP_SELF'];?>">
                        <div class="form group">
                            <label> We have sent an OTP to <?php echo "+91$number";?> </label>
                        </div>
                        <div class="input-group mb-3">
                            <input type="number" class="form-control" placeholder="Enter OTP" name="user_otp" required>
                            <div class="input-group-append">
                                <button class="btn btn-info" type="submit" name="sendOTP" id="submitButton" disabled="disabled">Resend</button>
                            </div>
                            </div>
                            <p id="timeLeft"></p>
                            <div class="form-group">
                                <label for="email">Enter Address</label>
                                <textarea class="form-control" row="6" name="address" required></textarea>
                            </div>
                            <div class="form-group">
                                <label >Enter City</label>
                                <input type="text" class="form-control" placeholder="City" name="city" required>
                            </div>
                            <div class="form-group">
                                <label>Enter Pincode</label>
                                <input type="number" class="form-control"  name="pincode" placeholder="Pincode" required>
                            </div>
                            <div class="form-group">
                                <label>Choose State</label>
                                <select name="state" class="form-control" required>
                                <option value="Andhra Pradesh">Andhra Pradesh</option>
                                <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                                <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                <option value="Assam">Assam</option>
                                <option value="Bihar">Bihar</option>
                                <option value="Chandigarh">Chandigarh</option>
                                <option value="Chhattisgarh">Chhattisgarh</option>
                                <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                                <option value="Daman and Diu">Daman and Diu</option>
                                <option value="Delhi">Delhi</option>
                                <option value="Lakshadweep">Lakshadweep</option>
                                <option value="Puducherry">Puducherry</option>
                                <option value="Goa">Goa</option>
                                <option value="Gujarat">Gujarat</option>
                                <option value="Haryana">Haryana</option>
                                <option value="Himachal Pradesh">Himachal Pradesh</option>
                                <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                                <option value="Jharkhand">Jharkhand</option>
                                <option value="Karnataka">Karnataka</option>
                                <option value="Kerala">Kerala</option>
                                <option value="Madhya Pradesh">Madhya Pradesh</option>
                                <option value="Maharashtra">Maharashtra</option>
                                <option value="Manipur">Manipur</option>
                                <option value="Meghalaya">Meghalaya</option>
                                <option value="Mizoram">Mizoram</option>
                                <option value="Nagaland">Nagaland</option>
                                <option value="Odisha">Odisha</option>
                                <option value="Punjab">Punjab</option>
                                <option value="Rajasthan">Rajasthan</option>
                                <option value="Sikkim">Sikkim</option>
                                <option value="Tamil Nadu">Tamil Nadu</option>
                                <option value="Telangana">Telangana</option>
                                <option value="Tripura">Tripura</option>
                                <option value="Uttar Pradesh">Uttar Pradesh</option>
                                <option value="Uttarakhand">Uttarakhand</option>
                                <option value="West Bengal">West Bengal</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Enter Landmark</label>
                                <input type="text" class="form-control"  name="landmark" placeholder="Landmark : Popular Place Near You" required>
                            </div>

                            <div class="form-group">
                                <label for="type">Address Type</label>
                                <div>
                                <label>Home</label>
                                <input type="radio" name="type" value="home" required>
                                <label>Work</label>
                                <input type="radio" name="type" value="work" required>
                                </div>
                            </div><br>
                            <center><button type="submit" name="submit" class="btn btn-success bg-ninja  text-center">Complete Registration</button></center>
                            </form>
                            </div>
                            <div class="container"><?php echo $error;?></div>
                            
                </div>
            </div>
        </div>
    </div>





    <script type="text/javascript">
        setTimeout (function(){
        document.getElementById('submitButton').disabled = null;
        },50000);

        var countdownNum = 47;
        incTimer();

        function incTimer(){
        setTimeout (function(){
            if(countdownNum != 0){
            countdownNum--;
            document.getElementById('timeLeft').innerHTML = 'Request for new OTP in : ' + countdownNum + ' seconds';
            incTimer();
            } else {
            document.getElementById('timeLeft').innerHTML = 'Request for new OTP!';
            }
        },1000);
        }
    </script>

<?php include 'includes/footer.php'?>
    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>