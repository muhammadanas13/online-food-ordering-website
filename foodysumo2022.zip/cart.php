<?php

include 'routers.inc.php';

if(isset($_GET['remove'])){
if($_GET['remove']=='all'){
    unset($_SESSION['cart']);
    redirect('shop');
}
if(isset($_GET['id'])){
    $rid = $_GET['id'];
    foreach($_SESSION['cart'] as $k => $part){
        if($rid==$part['id']){
            unset($_SESSION['cart'][$k]);
            unset($_SESSION['discount']);
            redirect('cart');
        }
    } 
}
}

$total=0;

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'includes/head.php';?>
    <title>Cart | FoodySumo.com</title>
    <style>



    </style>
  </head>
  <body>
 <?php include 'includes/navbar.php';?>
 
 
 <?php if(isset($_SESSION['cart'])){?>

 <div class="container mt-4">
 <div class="row">
     <div class="col-6"><h2 class="mr-3" style="display:inline">Cart</h2> <a href="cart?remove=all"><button class="btn btn-danger btn-sm mb-3">Remove all</button></a></div>
     
 </div>
  
  
  <table class="table table-striped" style="width:100%">
    <thead class="thead-dark">
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Remove</th>
      </tr>
    </thead>
    <tbody>
    
    <?php
    foreach($_SESSION['cart'] as $k => $item){?>

      <tr>
        <td><img src="uploads/dish/<?php echo $item['img'];?>" style="width:64px;height:auto"></td>
        <td><?php echo $item['dish']; ?></td>
        <td><?php echo $item['qty']; ?></td>
        <td><?php echo $item['price']*$item['qty'];
            $total = $total + $item['price']*$item['qty'];
        ?></td>
        
        <th><a href="cart?remove&id=<?php echo $item['id']; ?>"><button class="btn btn-danger">Remove</button></a></th>
      </tr>
      

      <?php }
      
      
      
      ?>
    
    </tbody>
    </table>
      </div>

      <div class="row d-flex justify-content-center">
        <div class="col-4 "><h6 style="font-size:22px">Total : <?php echo $total;?></h6></div>
        <div class="col-4"><a href="checkout"><button class="btn btn-info">CHECKOUT</button></a></div>
      </div>

    <?php }else{
        
        echo '
        <center>
        <img src="img/empty-cart.png" class=" mb-3">
        <h2 class="text-center display-4 text-gary">Cart is empty</h2>
        </center>
        ';}
        ?>
    
    



<?php include 'includes/footer.php'?>
    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>