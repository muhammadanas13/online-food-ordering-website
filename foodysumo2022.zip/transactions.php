<?php

include 'routers.inc.php';
if(!isset($_SESSION['u_name'])){
  redirect('index');
}

$sql = "select * from transaction where user_id='{$_SESSION['u_id']}' ORDER BY id DESC";
$sql_exec = mysqli_query($conn, $sql);

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'includes/head.php';?>

    <title>Orders | FoodySumo.com</title>
  </head>
  <body>
 <?php include 'includes/navbar.php';?>

 <div class="container mt-3">
		<div class="card">
			<div class="card-body">
				<div class="cart-title">
					<h4 class="display-4 card-head text-center text-white">All Transactions</h4>
						<?php if(mysqli_num_rows($sql_exec)>0){
             echo '
						<table id="foodtable" class="table table-striped" style="width:100%">
							<thead>
								<tr>
									<th>ID</th>
									<th>PAYMENT ID</th>
									<th>PAYMENT REQUEST ID</th>
									<th>STAUTUS</th>
								</tr>
							</thead>
							<tbody>'; $i=1; while($row = mysqli_fetch_assoc($sql_exec)){ 
                
                $rowID=$row['id'];
                
                echo '
								<tr>
									<td>'.$row['id'].'</td>
									<td>'.$row['payment_id'].'</td>
                                    <td>'.$row['payment_request_id'].'</td>
                                    <td>'.$row['payment_status'].'</td></tr>';
                } 				
                    echo '</tbody>
                  </table>'; }else{ echo "<h2 class='mb-4 mt-4 text-dark text-center'> No Transaction Found</h2>"; } ?>
					</div>
				</div>
			</div>
		</div>
	</div>
  


<?php include 'includes/footer.php'?>
    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>