<?php

session_start();
session_regenerate_id();

include "includes/config.inc.php";
include "includes/functions.inc.php";
include "includes/constants.inc.php";


?>