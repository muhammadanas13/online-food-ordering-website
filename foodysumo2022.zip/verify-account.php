<?php

include 'routers.inc.php';

if(!isset($_GET['token'])){
    redirect('index');
    die();
}else{

    $token = mysqli_real_escape_string($conn,$_GET['token']);

        $fetchData = "select * from users where email='{$email}'";
        $execFetech = mysqli_query($conn, $fetchData);
        $showData = mysqli_fetch_assoc($execFetech);

        if($showData['status']=-2){

            $_SESSION['otp'] = $showData['sms_otp'];
            $_SESSION['u_email'] = $showData['email'];
            $_SESSION['u_mobile'] = $showData['mobile'];
            $update = "update users set token = 'null',status='1' where token='{$token}' ";
            $valUpdate = mysqli_query($conn,$update);
            
            redirect('step-2');
            die();

        }else{
            $update = "update users set token = 'null',status='1' where token='{$token}' ";
            $valUpdate = mysqli_query($conn,$update);
            redirect("index?alert=account-created");
            die();
        }
    

}

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'includes/head.php';?>
    <title>Email Verification | FoodySumo.com</title>
  </head>
  <body>


 <div class="container mt-4 mb-2">
        <div class="row d-flex justify-content-center">
            <div class="col-md-4">
                <div class="card vcenter">
                    <div class="card-body">
                    <h2 class="card-title display-6 text-white text-center rounded py-2 mb-4 card-head ">Login</h2>
                        <form class="mt-2" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                            <div class="form-group">
                                <label for="email">Enter Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" name="password" required>
                            </div>
                            <center><button type="login" name="submit" class="btn btn-success bg-ninja">LOGIN</button></center>
                            </form>

                            <div class="container">
                                <?php echo $error;?>
                            </div>
                            </div>
                </div>
            </div>
        </div>
    </div>

<?php include 'includes/footer.php'?>
    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>