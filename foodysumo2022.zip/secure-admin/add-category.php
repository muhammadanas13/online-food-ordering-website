<?php
include "loader.inc.php";

$error="";

if(isset($_POST['submit'])){

    $category = mysqli_real_escape_string($conn,$_POST['category']);
    $ordernumber = mysqli_real_escape_string($conn,$_POST['ordernumber']);
    $status = '1';

    $sorting = "select * from category where order_number = '$ordernumber' or category='$category' ";
    $runSorting = mysqli_query($conn,$sorting);
    // $chkk = mysqli_num_rows($runSorting);
    // var_dump($chkk);
    // die();
    if(mysqli_num_rows($runSorting)==0){

        $sql = "insert into category(category,order_number,status) values('{$category}','{$ordernumber}','{$status}')";
        $exec_in = mysqli_query($conn,$sql);

            if($exec_in){
            redirect('category');
            die();
            } 
    }
    else{
       $error = alert_info ("Category or Order number already exist");
    }

        
}




?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  'assets/head.php';?>
    <title>Add Category</title>
  </head>
<body>

<?php include "assets/navbar.php";?>
    <div class="container">
        <div class="row d-flex justify-content-center container-vcenter mb-3">
                <div class="col-md-5">
                <div class="card">
                    <div class="card-body">
                    <h4 class="card-title card-head display-6 text-white text-center rounded py-2 mb-4">Add Category</h4>
                        <form method="POST" action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>" class="m-2">
                            <div class="form-group">
                                <label for="category">Enter Category</label>
                                <input type="text" name="category" class="form-control" id="category" placeholder="Category Type : Indian/Chinese" required>
                            </div>

                            <div class="form-group">
                                <label for="order_number">Order Number</label>
                                <input type="number" class="form-control"  name="ordernumber" placeholder="Order Number"  required>
                            </div>

                            <input type="hidden" name="status" value="1">

                            <button type="submit" name="submit" class="btn btn-primary btn-lg">Add Category</button>
                            </form>
                    </div>

                    <div class="container">
                            <?php echo $error; ?>
                    </div>


                    </div>
                </div>

                </div>

        </div>
    </div>

<?php include 'assets/footer.php';?>
</body>
</html>