<?php

include "loader.inc.php";

$sql = "select * from delivery_boy order by id desc";
$sql_exec = mysqli_query($conn,$sql);

if(isset($_GET['id'])){
  $user_id = $_GET['id'];

  if($_GET['status']=='inactive' && $user_id>0){
    $updateStatus = "update delivery_boy set status='1' where id='{$user_id}'";
    $runStatus = mysqli_query($conn,$updateStatus);
    if($runStatus){
      redirect('delivery-boys');
      die();
    }
  }

  if($_GET['status']=='active' && $user_id>0){
    $updateStatus = "update delivery_boy set status='0' where id='{$user_id}'";
    $runStatus = mysqli_query($conn,$updateStatus);
    if($runStatus){
      redirect('delivery-boys');
      die();
    }
  }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  'assets/head.php';?>
    <title>Delivery Boys</title>
  </head>
<body>
<?php include 'assets/navbar.php';?>

<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <div class="cart-title">
                <h4 class="display-4 card-head text-center text-white">DELIVERY BOYS</h4>

              <div class="mt-2 mb-2 py-2">
                <a href="add-delivery-boy"><button class="btn btn-primary">Add Delivery Boy</button></a>
              </div>

                <?php
              if(mysqli_num_rows($sql_exec)>0){
                echo '<table id="foodtable" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NAME</th>
                        <th>NUMBER</th>
                        <th>Added On</th>
                        <th>STATUS</th>
                    </tr>
                </thead>
                <tbody>';
                  $i=1;
                  while($row = mysqli_fetch_assoc($sql_exec)){
                    echo '<tr>
                    <td>'.$row['id'].'</td>
                    <td>'.$row['name'].'</td>
                    <td>'.$row['mobile'].'</td>
                    <td>'.$row['added_on'].'</td>';?>
                    <?php
                      if($row['status']==1){
                        echo '<td><a href="delivery-boys?id='.$row['id'].'&status=active"><button type="submit" class="btn btn-success btn-sm" name="status" >Active</button></a></td></tr>';
                      }else{
                        echo '<td><a href="delivery-boys?id='.$row['id'].'&status=inactive"><button type="submit" class="btn btn-danger btn-sm" name="status" >Inactive</button></a></td></tr>';
                      }
                     $i=$i+1;

                  }
                  echo '</tbody>
                  </table>';
              }else{
                echo "<h2 class='mb-4 mt-4 text-dark text-center'> No User Found</h2>";
              }

            ?>
            </div>
        </div>
    </div>
</div>

<?php include 'assets/footer.php';?>
</body>
</html>