<?php
include "loader.inc.php";

$error = "";
$name = $username = $email = "";


if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

        $checkEmail = mysqli_query($conn,"select email,username from admin ");

        if(mysqli_num_rows($checkEmail)>0){
            if($password==$cpassword){
            
                $hashPass = password_hash($password, PASSWORD_BCRYPT);
    
                $sql = "insert into admin(name,username,email,password) values('$name','$username','$email','$hashPass')";
    
                $insertData = mysqli_query($conn,$sql);
    
                if($insertData){
    
                    $error = alert_success("Admin has been added successfully!");
    
                    $email=$name=$username="";
                }
            }
            else{
                $error = "Please enter same Password!";
            }
        }else{
            $error = alert_danger("Admin already exists, Please check your entered username and email!");
        }

        
    }

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  "assets/head.php";?>
    <title>Add Admin</title>
  </head>
<body>
<?php include "assets/navbar.php";?>

<div class="container mt-5">
<div class="row">
  <div class="col-3">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
    <a class="nav-link" href="settings#v-pills-home">Profile</a>
    <a class="nav-link" href="settings#v-pills-messages">Change Password</a>
      <a class="nav-link active"  href="add-admin">Add Admin</a>
    </div>
  </div>

    <div class="col-9">
        <div class="row d-flex justify-content-center">
                <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                    <h4 class="card-title card-head display-6 text-white text-center rounded py-2 mb-4">Add New Admin</h4>
                        <form method="POST" action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>" class="m-2">
                            <div class="form-group">
                                <label for="name">Enter Full Name</label>
                                <input type="text" name="name" class="form-control" id="name" placeholder="Enter Name" value="<?php echo $name;?>" required>
                            </div>

                            <div class="form-group">
                                <label for="username">Enter Username</label>
                                <input type="text" class="form-control" id="username"  name="username" placeholder="Enter Username" value="<?php echo $username;?>" required>
                            </div>

                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" class="form-control" id="email"  name="email"  placeholder="Enter Email" value="<?php echo $email;?>" required>
                            </div>

                            <div class="form-group">
                                <label for="password">Enter Password</label>
                                <input type="password" class="form-control" id="password"  name="password" placeholder="Enter Password" required>
                            </div>


                            <div class="form-group">
                                <label for="cpassword">Confirm Password</label>
                                <input type="password" class="form-control" id="cpassword"  name="cpassword" placeholder="Confirm Password" required>
                            </div>
                            <button type="submit" name="submit" class="btn btn-primary btn-lg">Add Admin</button>
                            </form>
                    </div>

                    <div class="container">
                            <?php echo $error; ?>
                    </div>


                    </div>
                </div>

                </div>
            </div>
        </div>
    </div>
<?php include("assets/footer.php");?>
</body>
</html>