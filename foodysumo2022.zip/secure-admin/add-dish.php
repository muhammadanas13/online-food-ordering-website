<?php
    include "loader.inc.php";
    $error = "";
        if(isset($_POST['submit'])){

            $dish = mysqli_real_escape_string($conn,$_POST['dish']);
            $dish_details = mysqli_real_escape_string($conn,$_POST['dish_details']);
            $category = mysqli_real_escape_string($conn,$_POST['category']);
            $price = mysqli_real_escape_string($conn,$_POST['price']);
            $alpha = bin2hex(random_bytes(5));
            $image = strtolower($alpha.$_FILES['image']['name']);
            $location = "../uploads/dish/";
            $tempName = $_FILES['image']['tmp_name'];
            $extensions = array('image/jpeg', 'image/jpg','image/png', 'image/gif');
            $imgEx = $_FILES['image']['type'];
            $sql = "INSERT INTO `dish` (`category_id`, `dish`, `price`, `dish_details`, `image`, `status`) VALUES ('$category','$dish', '$price','$dish_details', '$image','1')";
            
            $sqlSelect = mysqli_query($conn,"select * from dish");
    
            if(mysqli_num_rows($sqlSelect)){
                if(in_array($imgEx,$extensions)==true){
                    if(move_uploaded_file($tempName, $location.$image)){
                        
                        $sql_exec = mysqli_query($conn,$sql);
            
                            if($sql_exec){
                                redirect('dishes');
                                die();
                            }else{
                                $error = alert_info("Error in adding new dish, please try after sometime.");
                            }
                    }
                    else{
                        $error = alert_info("Upload failed");
                    }
                }
                else{
                    $error = alert_danger("Only JPG, JPEG and PNG are allowed to upload.");
                }
            }else{
                $error = alert_info("Dish already exist!");
            }
     }

    

    

    $sqlCat = "select * from category where status='1' order by category asc";
    $sqlCate = mysqli_query($conn, $sqlCat);

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  'assets/head.php';?>
    <title>Add Dish</title>
  </head>
<body>
<?php include 'assets/navbar.php';?>
<div class="container">
        <div class="row d-flex justify-content-center container-vcenter mb-3">
                <div class="col-md-5">
                <div class="card">
                    <div class="card-body">
                    <h4 class="card-title card-head display-6 text-white text-center rounded py-2 mb-4">
                    Add Dish
                    </h4>
            <form method="POST" action="<?php echo $_SERVER['PHP_SELF'];?>" class="m-2" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Enter Dish Name</label>
                        <input type="text" name="dish" class="form-control" placeholder="Dish Name" required>
                    </div>


                    <div class="form-group">
                        <label>Select Category</label>
                        <select class="form-control" name="category">
                        <option>Select Category</option>
                        <?php
                            while($cat_data=mysqli_fetch_array($sqlCate)){
                               echo "<option value=".$cat_data['id'].">".$cat_data['category']."</option>";
                            }
                        ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Enter Price</label>
                        <input name="price" class="form-control" placeholder="Price" type="number" required>
                    </div>


                    <div class="form-group">
                        <label>Enter Dish Details</label>
                        <textarea name="dish_details" row="4" class="form-control" placeholder="Enter full details of the dish..." required></textarea>
                    </div>

                    <div class="form-group">
                        <label for="order_number">Choose Image</label>
                        <input type="file" class="form-control-file" name="image" placeholder="Upload" required>
                    </div>
                    
                    <button type="submit" name="submit" class="btn btn-primary btn-md">Add Dish</button>
        </form>

                            <?php echo $error; ?>
                    </div>
                    </div>
                </div>

                </div>

        </div>
    </div>

<?php include 'assets/footer.php';?>
</body>
</html>