<?php 
include "loader.inc.php";
$sql = "select * from category";
$sql_exec = mysqli_query($conn, $sql);
if (isset($_GET['id'])) {
    $cat_id = $_GET['id'];
    if ($_GET['status'] == 'inactive' && $cat_id > 0) {
        $updateStatus = "update category set status='1' where id='{$cat_id}'";
        $runStatus = mysqli_query($conn, $updateStatus);
        if ($runStatus) {
            redirect('category');
            die();
        }
    }
    if ($_GET['status'] == 'active' && $cat_id > 0) {
        $updateStatus = "update category set status='0' where id='{$cat_id}'";
        $runStatus = mysqli_query($conn, $updateStatus);
        if ($runStatus) {
            redirect('category');
            die();
        }
    }
    if ($_GET['action'] == 'delete' && $cat_id > 0) {
        $deleteCat = "delete from category where id='{$cat_id}'";
        $runDelete = mysqli_query($conn, $deleteCat);
        if ($runDelete) {
            redirect('category');
            die();
        }
    }
} ?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<?php include 'assets/head.php';?>
	<title>Category</title>
</head>

<body>
	<?php include 'assets/navbar.php';?>
	<div class="container mt-3">
		<div class="card">
			<div class="card-body">
				<div class="cart-title">
					<h4 class="display-4 card-head text-center text-white">ALL CATEGORY</h4>
					<div class="container mt-3">
						<div class="d-flex justify-content-left mb-3"><a href="add-category" class="btn btn-sm btn-info">Add Category</a>
						</div>
						<?php if(mysqli_num_rows($sql_exec)>0){
             echo '
						<table id="foodtable" class="table table-striped" style="width:100%">
							<thead>
								<tr>
									<th>ID</th>
									<th>NAME</th>
									<th>ORDER ID</th>
									<th>STATUS</th>
									<th>ACTION</th>
								</tr>
							</thead>
							<tbody>'; $i=1; while($row = mysqli_fetch_assoc($sql_exec)){ 
                
                $rowID=$row['id'];
                
                echo '
								<tr>
									<td>'.$i.'</td>
									<td>'.$row['category'].'</td>
									<td>'.$row['order_number'].'</td>';?>
									<?php if($row[ 'status']==1){ echo '<td><a href="category?id='.$row[ 'id']. '&status=active"><button type="submit" class="btn btn-success btn-sm" name="status" >Active</button></a></td>'; }else{ echo '<td><a href="category?id='.$rowID. '&status=inactive"><button type="submit" class="btn btn-danger btn-sm" name="status" >Inactive</button></a></td>'; } echo '
                    <td>
                    <a href="update-category?id='.$rowID.'" class="btn btn-info btn-sm mr-2 text-white"><i class="fas fa-pen"></i></a>
                    <a href="category?id='.$rowID. '&action=delete" class="btn btn-danger btn-sm mr-2 text-white"><i class="fa fa-trash-alt"></i></a>

                    </td>'; $i=$i+1; } echo '</tbody>
                  </table>'; }else{ echo "<h2 class='mb-4 mt-4 text-dark text-center'> No User Found</h2>"; } ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php include 'assets/footer.php';?>
</body>

</html>