<?php

include 'loader.inc.php';


$c_expiry = $error = "";
if(isset($_POST['submit'])){
  $c_code = $_POST['c_code'];
  $c_value = $_POST['c_value'];
  $c_type = $_POST['c_type'];
  $c_min_cart_value = $_POST['c_min_value'];
  $c_user_type=$_POST['user_type'];
  $c_expiry = $_POST['c_expiry'];

    $checkCoupon = mysqli_query($conn,"select * from coupon_code where coupon_code ='{$c_code}' ");

    if(mysqli_num_rows($checkCoupon)==0){

        $insertCoupon = "INSERT INTO coupon_code (`coupon_code`, `coupon_type`, `coupon_value`, `cart_min_value`,`user_order`, `expired_on`, `status`) VALUES ('$c_code', '$c_type', '$c_value', '$c_min_cart_value', '$c_user_type','$c_expiry', '1')";
        $runCoupon = mysqli_query($conn,$insertCoupon);
    
        if($runCoupon){
            redirect('coupons');
        }
    }
    else{
      $error = alert_info("Coupon code already exists");
    }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  'assets/head.php';?>
    <title>Add Coupon Code</title>
  </head>
<body>
<?php include 'assets/navbar.php';?>


<div class="container">
        <div class="row d-flex justify-content-center container-vcenter mb-3">
                <div class="col-md-5">
                <div class="card">
                    <div class="card-body">
                    <h4 class="card-title card-head display-6 text-white text-center rounded py-2 mb-4">Add Coupon Code</h4>
                        <form method="POST" action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>" class="m-2">
                        <div class="form-group">
            <label>Coupon Code</label>
            <input type="text" name="c_code" class="form-control" placeholder="Flat40" required>
      </div>

         <div class="form-group ">
         <label>Coupon Type</label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="c_type" value="P" required>
                <label class="form-check-label">PERCENTAGE</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="c_type" value="F" required>
                <label class="form-check-label">FIXED</label>
            </div>
        </div>


        <div class="form-group">
            <label>Coupon Value</label>
            <input type="number" class="form-control" name="c_value" placeholder="30" required>
        </div>


        <div class="form-group">
            <label for="order_number">Minimum Cart Value</label>
            <input type="number" class="form-control" name="c_min_value" placeholder="200" required>
        </div>

        <div class="form-group ">
         <label>User Type</label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="user_type" value="O" required>
                <label class="form-check-label">Old User</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="user_type" value="P" required>
                <label class="form-check-label">New Users</label>
            </div>
        </div>


        <div class="form-group">
            <label for="order_number">Coupon Expiry</label>
            <input type="date" class="form-control" name="c_expiry">
            <small>Leave blank if you do not want to set expiry</small>
        </div>
        
        <button type="submit" name="submit" class="btn btn-primary btn-lg">Add</button>
        </form>

                            <?php echo $error; ?>
                    </div>
                    </div>
                </div>

                </div>

        </div>
    </div>


<?php include 'assets/footer.php';?>
</body>
</html>