<?php
include "../includes/config.inc.php";
include "../includes/functions.inc.php";
include "session.php";

$sql = "select * from users";
$sql_exec = mysqli_query($conn,$sql);

if(isset($_GET['id'])){
  $user_id = $_GET['id'];

  if($_GET['status']=='inactive' && $user_id>0){
    $updateStatus = "update users set status='1' where id='{$user_id}'";
    $runStatus = mysqli_query($conn,$updateStatus);
    if($runStatus){
      redirect('users');
      die();
    }
  }

  if($_GET['status']=='active' && $user_id>0){
    $updateStatus = "update users set status='0' where id='{$user_id}'";
    $runStatus = mysqli_query($conn,$updateStatus);
    if($runStatus){
      redirect('users');
      die();
    }
  }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  'assets/head.php';?>
    <title>Users</title>
  </head>
<body>
<?php include 'assets/navbar.php';?>

<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <div class="cart-title">
                <h4 class="display-4 card-head text-center text-white rounded">ALL USERS</h4>
            </div>

            <?php
              if(mysqli_num_rows($sql_exec)>0){
                echo '<table id="foodtable" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NAME</th>
                        <th>EMAIL</th>
                        <th>NUMBER</th>
                        <th>ADDED ON</th>
                        <th>STATUS</th>
                    </tr>
                </thead>
                <tbody>';
                  $i=1;
                  while($row = mysqli_fetch_assoc($sql_exec)){
                    echo '<tr>
                    <td>'.$i.'</td>
                    <td>'.$row['name'].'</td>
                    <td>'.$row['email'].'</td>
                    <td>'.$row['mobile'].'</td>
                    <td>'.$row['added_on'].'</td>';?>
                    <?php
                      if($row['status']==1){
                        echo '<td><a href="users?id='.$row['id'].'&status=active"><button type="submit" class="btn btn-success btn-sm" name="status" >Active</button></a></td></tr>';
                      }else{
                        echo '<td><a href="users?id='.$row['id'].'&status=inactive"><button type="submit" class="btn btn-danger btn-sm" name="status" >Inactive</button></a></td></tr>';
                      }
                     $i=$i+1;
                  }
                  echo '</tbody>
                  </table>';
              }else{
                echo "<h2 class='mb-4 mt-4 text-dark text-center'> No User Found</h2>";
              }

            ?>
        </div>
    </div>
</div>

<?php include 'assets/footer.php';?>
</body>
</html>