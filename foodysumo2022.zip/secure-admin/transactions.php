<?php 
include "loader.inc.php";
$sql = "select * from transaction ORDER BY id DESC";
$sql_exec = mysqli_query($conn, $sql);

function user_name($uid){
    global $conn;
    $readUser = mysqli_query($conn,"select * from users where id=$uid");
    $rowUser = mysqli_fetch_assoc($readUser);
    echo $rowUser['email'];
}


?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<?php include 'assets/head.php';?>
	<title>Transaction</title>
</head>

<body>
	<?php include 'assets/navbar.php';?>
	<div class="container mt-3">
		<div class="card">
			<div class="card-body">
				<div class="cart-title">
					<h4 class="display-4 card-head text-center text-white">All Transactions</h4>
						<?php if(mysqli_num_rows($sql_exec)>0){
             echo '
						<table id="foodtable" class="table table-striped" style="width:100%">
							<thead>
								<tr>
									<th>ID</th>
									<th>USER EMAIL</th>
									<th>PAYMENT ID</th>
									<th>PAYMENT REQUEST ID</th>
									<th>STAUTUS</th>
								</tr>
							</thead>
							<tbody>'; $i=1; while($row = mysqli_fetch_assoc($sql_exec)){ 
                
                $rowID=$row['id'];
                
                echo '
								<tr>
									<td>'.$row['id'].'</td>
									<td>';
                                    user_name($row['user_id']);echo'</td>
									<td>'.$row['payment_id'].'</td>
                                    <td>'.$row['payment_request_id'].'</td>
                                    <td>'.$row['payment_status'].'</td>';
                } 
                    echo '</tbody>
                  </table>'; }else{ echo "<h2 class='mb-4 mt-4 text-dark text-center'> No Transaction Found</h2>"; } ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php include 'assets/footer.php';?>
</body>

</html>