<nav class="navbar navbar-expand-lg navbar-dark nav-dark-bg">
   <a class="navbar-brand" href="dashboard"><img src="../img/site-icon.png" style="line-height:50%;width:40px;height:auto" alt="Logo"> FoodySumo</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
   <i class="fas fa-align-right"></i>
   </button>
   <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto ml-md-5">
         <li class="nav-item active">
            <a class="nav-link ml-md-2 mr-md-2" href="dashboard"><i class="fas fa-chart-bar mr-sm-2"></i> Dashboard </a>
         </li>
         <li class="nav-item">
            <a class="nav-link ml-md-2 mr-md-2" href="orders"><i class="fas fa-clipboard-list mr-sm-2"></i> Orders </a>
         </li>
         <li class="nav-item">
            <a class="nav-link ml-md-2 mr-md-2" href="users"> <i class="fas fa-user-friends mr-sm-2"></i> Users</a>
         </li>
         <li class="nav-item">
            <a class="nav-link ml-md-2 mr-md-2" href="delivery-boys"><i class="fas fa-truck mr-sm-2"></i> Delivery Boys</a>
         </li>
         <li class="nav-item">
            <a class="nav-link ml-md-2 mr-md-2" href="category"><i class="fas fa-utensils mr-sm-2"></i> Category </a>
         </li>
         <li class="nav-item">
            <a class="nav-link ml-md-2 mr-md-2" href="dishes"><i class="fas fa-hamburger mr-sm-2"></i> Dishes </a>
         </li>

         <li class="nav-item">
            <a class="nav-link ml-md-2 mr-md-2" href="coupons"><i class="fas fa-percent mr-sm-2"></i> Coupons </a>
         </li>
      </ul>
      <ul class="navbar-nav mr-sm-2">
      <li class="nav-item dropdown">
         <a href="" class="nav-link dropdown-toggle text-white rounded accDropdown" data-toggle="dropdown"  id="accDropdown">
         <i class="fas fa-user-alt mr-sm-2"> </i> <?php echo $_SESSION['name']; ?></a> 
         <div class="dropdown-menu" aria-labelledby="accDropdown">
            <a href="settings" class="dropdown-item"><i class="fas fa-cog"></i> Setting</a>
            <a href="signout" class="dropdown-item text-danger"><i class="fas fa-power-off"> </i> Logout</a>
         </div>
      </li>
      <ul>
   </div>
</nav>