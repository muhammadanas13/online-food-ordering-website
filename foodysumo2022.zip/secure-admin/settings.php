<?php
include "loader.inc.php";

$error="";
$user_id = $_SESSION['id'];
$sql = "select * from admin where id='{$user_id}'";
$sql_exec = mysqli_query($conn,$sql);
$row=mysqli_fetch_array($sql_exec);
$name = $row['name'];
$username = $row['username'];
$email = $row['email'];

if(isset($_POST['changepassword'])){
    $oldpassword = mysqli_real_escape_string($conn,$_POST['oldpassword']);
    $password = mysqli_real_escape_string($conn,$_POST['password']);
    $cpassword = mysqli_real_escape_string($conn,$_POST['cpassword']);
    $current_password = $row['password'];
    if(password_verify($oldpassword,$current_password)){
        if($password==$cpassword){
            $hashPassword = password_hash($password, PASSWORD_BCRYPT);
            $updatePass = "update admin set password = '{$hashPassword}' where id='{$user_id}'";
            $update_exec = mysqli_query($conn,$updatePass);
            if($update_exec){
                $error = alert_success("Password has been updated successfully");
            }
        }
        else{
            $error=alert_danger("Your entered Password has not matched with Confirm Password");
        }
    }else{
        $error=alert_danger("Your Current Password is Incorrect..!");
    }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  'assets/head.php';?>
    <title>Settings</title>
    <style>
        .nav .nav-link{
            font-weight:600;
        }
    </style>
  </head>
<body>
<?php include 'assets/navbar.php';?>

<div class="container mt-5">
<div class="row">
  <div class="col-3">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
    <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">Profile</a>
      <a class="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">Change Password</a>
      <a class="nav-link"  href="add-admin">Add Admin</a>
    </div>
  </div>
  <div class="col-9">
    <div class="tab-content" id="v-pills-tabContent">
      <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
      <div class="card-body">
                    <h2 class="card-title display-6 text-white card-head text-center rounded py-2 mb-4">Profile Setting</h2>
                        <form class="mt-2" method="POST" actio="<?php echo htmlentities($_SERVER['PHP_SELF']);?>">
                            <div class="form-group">
                                <label for="Name">Full Name</label>
                                <input type="text" class="form-control" id="oldpassword" name="name" required value="<?php echo $name; ?>">
                            </div>
                            <div class="form-group">
                                <label for="email">Username</label>
                                <input type="username" class="form-control" id="username" name="username"  value="<?php echo $username;?>" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" value="<?php echo $email;?>" name="mobile" required>
                            </div>
                            <button type="submit" name="updateprofile" class="btn btn-primary">Update Profile</button>
                            </form>
                            <?php
                            if($error){
                                echo $error;
                            }
                            ?>
                    </div>
        </div>

      <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
      <div class="card-body">
                    <h2 class="card-title display-6 text-white card-head text-center rounded py-2 mb-4">Change Password</h2>
                        <form class="mt-2" method="POST" actio="<?php echo htmlentities($_SERVER['PHP_SELF']);?>">
                            <div class="form-group">
                                <label for="oldpassword">Current Password</label>
                                <input type="text" class="form-control" id="oldpassword" name="oldpassword" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Enter New Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="form-group">
                                <label for="cpassword">Confirm Password</label>
                                <input type="password" class="form-control" id="cpassword" name="cpassword" required>
                            </div>
                            <button type="submit" name="changepassword" class="btn btn-primary">Change Password</button>
                            </form>
                            <?php
                            if($error){
                                echo $error;
                            }
                            ?>
                    </div>
        </div>
    </div>
  </div>
</div>
</div>
<?php include 'assets/footer.php';?>
</body>
</html>
