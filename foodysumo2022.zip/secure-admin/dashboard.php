<?php
    include "loader.inc.php";

    $users = mysqli_num_rows(mysqli_query($conn,"select id from users"));
    $orders = mysqli_num_rows(mysqli_query($conn,"select id from orders"));
    $categories = mysqli_num_rows(mysqli_query($conn,"select id from category"));
    $dishes = mysqli_num_rows(mysqli_query($conn,"select id from dish"));

    $delivery_boys = mysqli_num_rows(mysqli_query($conn,"select id from delivery_boy"));
    $coupons = mysqli_num_rows(mysqli_query($conn,"select id from coupon_code where status='1'"));
    $admins = mysqli_num_rows(mysqli_query($conn,"select id from admin"));
    $onOrder = "0";
    

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  'assets/head.php';?>
    <title>Admin Login</title>
  </head>
<body>
<?php include 'assets/navbar.php';?>
<div class="container mt-3">

<div class="row mb-3">
<div class="col-xl-3 col-lg-6">
            <div class="card dashboard-card card-inverse card-success">
              <div class="dashboard-card-block bg-success">
                <div class="dashboard-rotate">
                  <i class="fa fa-users fa-5x"></i>
                </div>
                <h6 class="text-uppercase text-white font-weight-bolder p-3">Users</h6>
                <h2 class="display-3 px-2 text-white mt-0"><?php echo $users;?></h2>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-6">
            <div class="card dashboard-card card-inverse card-danger">
              <div class="dashboard-card-block bg-danger">
                <div class="dashboard-rotate">
                  <i class="fas fa-clipboard-list fa-5x"></i>
                </div>
                <h6 class="text-uppercase text-white font-weight-bolder p-3">Total Orders</h6>
                <h2 class="display-3 px-2 text-white mt-0"><?php echo $orders;?></h2>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-6">
            <div class="card dashboard-card card-inverse card-info">
              <div class="dashboard-card-block bg-info">
                <div class="dashboard-rotate">
                  <i class="fas fa-utensils fa-5x"></i>
                </div>
                <h6 class="text-uppercase text-white font-weight-bolder p-3">Categories</h6>
                <h2 class="display-3 px-2 text-white mt-0"><?php echo $categories;?></h2>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-6">
            <div class="card dashboard-card card-inverse card-warning">
              <div class="dashboard-card-block bg-warning">
                <div class="dashboard-rotate">
                  <i class="fas fa-hamburger fa-5x"></i>
                </div>
                <h6 class="text-uppercase text-white font-weight-bolder p-3">Dishes</h6>
                <h2 class="display-3 px-2 text-white mt-0"><?php echo $dishes;?></h2>
              </div>
            </div>
        </div>
</div>

<!--- Second ROW-->

    <div class="row mb-3">
    <div class="col-xl-3 col-lg-6">
            <div class="card dashboard-card card-inverse card-warning">
              <div class="dashboard-card-block bg-warning">
                <div class="dashboard-rotate">
                  <i class="fas fa-percent fa-5x"></i>
                </div>
                <h6 class="text-uppercase text-white font-weight-bolder p-3">Active Coupons</h6>
                <h2 class="display-3 px-2 text-white mt-0"><?php echo $coupons;?></h2>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-6">
            <div class="card dashboard-card card-inverse card-info">
              <div class="dashboard-card-block bg-info">
                <div class="dashboard-rotate">
                  <i class="fa fa-lock fa-5x"></i>
                </div>
                <h6 class="text-uppercase text-white font-weight-bolder p-3">Admins</h6>
                <h2 class="display-3 px-2 text-white mt-0"><?php echo $admins;?></h2>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-6">
            <div class="card dashboard-card card-inverse card-danger">
              <div class="dashboard-card-block bg-danger">
                <div class="dashboard-rotate">
                  <i class="fas fa-truck fa-5x"></i>
                </div>
                <h6 class="text-uppercase text-white font-weight-bolder p-3">Delivery Boys</h6>
                <h2 class="display-3 px-2 text-white mt-0"><?php echo $delivery_boys;?></h2>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-lg-6">
            <div class="card dashboard-card card-inverse card-success">
              <div class="dashboard-card-block bg-success">
                <div class="dashboard-rotate">
                  <i class="fa fa-road fa-5x"></i>
                </div>
                <h6 class="text-uppercase text-white font-weight-bolder p-3">Active Orders</h6>
                <h2 class="display-3 px-2 text-white mt-0"><?php echo $onOrder;?></h2>
              </div>
            </div>
          </div>
          </div>
    </div>
</div>
<div style="padding-top:3em;width:100%;position:fixed;bottom:0">
<?php include 'assets/footer.php';?>
</div>
</body>
</html>