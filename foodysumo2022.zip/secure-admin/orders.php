<?php
    include 'loader.inc.php';

      if(isset($_POST['action_status'])){
        $action_status = $_POST['action_status'];
        $up_id = $_POST['action_oid'];

        $sql_up = "update orders set status = '{$action_status}' where id = '{$up_id}'";
        $up_status = mysqli_query($conn,$sql_up);
        if($up_status){
        redirect('orders?alert=updated');
        }

      }

    function action_button($o_status){
      
      if($o_status==0){
         echo '<button class="btn btn-danger btn-sm" disabled>Pending</button>';
      }elseif($o_status==1){
          echo '<button class="btn btn-warning btn-sm" disabled>Preparing</button>';
      }elseif($o_status==2){
          echo '<button class="btn btn-primary btn-sm" disabled>Rider Acceptance</button>';
      }elseif($o_status==3){
          echo '<button class="btn btn-info btn-sm" disabled>On the way</button>';
      }elseif($o_status==-1){
          echo '<button class="btn btn-danger btn-sm" disabled>Cancelled</button>';
      }else{
        echo '<button class="btn btn-success btn-sm" disabled>Delivered</button></a>';
      }


    }
   
  
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  'assets/head.php';?>
    <title>Orders</title>
    <style>
      .alert{
    position: fixed;
    top: 10%;
    right: 1%;
    width: auto;
}
      </style>
  </head>
<body>
<?php include 'assets/navbar.php';?>

<div class="mr-2 ml-2 mt-3">
		<div class="card">
			<div class="card-body">
				<div class="cart-title">
					<h4 class="display-4 card-head text-center text-white">Order History</h4>
					<div class="container mt-3">
						</div>
						<table id="foodtable" class="table table-striped" style="width:100%">
                <?php 
                $uid = $_SESSION['id'];

                function delivery_boy($d_id){
                  if($d_id!=0){
                  $delivery_r = "select * from delivery_boy where id='{$d_id}'";
                  global $conn;
                  $d_data = mysqli_query($conn,$delivery_r);
                  $dr_data=mysqli_fetch_assoc($d_data);
                  return $dr_data['name'];
                  }else{
                    return $dr_data = "Not Assigned";
                  }
                  
                }  
                $sql = "select * from orders ORDER BY id DESC";
                $fetch = mysqli_query($conn,$sql);
                if(mysqli_num_rows($fetch)){
                  echo '							<thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Dishes</th>
                    <th>Payment</th>
                    <th>Amount</th>
                    <th>Discount</th>
                    <th>Address</th>
                    <th>Rider</th>
                    <th>STATUS</th>
                    <th>Date</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>';
                  while($row=mysqli_fetch_assoc($fetch)){
                    echo '
                    
                    <tr>
                        <td>'.$row['id'].'</td>
                        <td>'.$row['name'].'</td>
                        <td>'.rtrim($row['product'],",").'</td>
                        <td>';
                        
                        if($row['method']==1){
                          echo 'COD';
                        }else{
                          echo 'Paid Online';
                        }
                        echo '</td>
                        <td>'.$row['total'].'</td>
                        <td>'.$row['discount'].'</td>
                        <td>'.$row['address'].'</td>
                        <td>';

                        echo delivery_boy($row['rider_id']);echo'</td>
                        
                        <td>
                        ';
                        action_button($row['status']);
                        echo'</td>
                        <td>'.$row['date'].'</td>
                        <td>
                        <form method="post" action="">
                        <div class="form-group">
                        <select class="form-control" name="action_status" onchange="form.submit()">
                        <option>Select</>
                        <option value="0">Pending</option>
                        <option value="1">Preparing</option>
                        <option value="2">Auto Assign</option>
                        <option value="3">OntheWay</option>
                        <option value="-1">Cancelled</option>
                        </select>
                        </div>
                        <input type="hidden" value="'.$row['id'].'" name="action_oid">
                        </form>
                       </td>
                    </tr>
                    ';
                  }  
                ?>

</tbody>
              <?php 
              }
              else 
              { echo "<h2 class='text-center text-muted my-3'>No Order Found</h2>" ;} 
              ?>
						
                </table>
					</div>
				</div>
			</div>
		</div>
	</div>

  <script type="text/javascript">
		setTimeout(function () {
			$('.alert').alert('close');
		}, 4000);
	</script>

<?php

if(isset($_GET['alert'])=='updated'){
  echo alert_info('Order status has been updated');
}
?>
<?php include 'assets/footer.php';?>
</body>
</html>



<!-- // if(mysqli_num_rows($srun)==0){
//     echo "<h1>No order has found</h1>"
// }else{

// while($data=mysqli_fetch_assoc($srun)){ ?>


//     <td></td>

// 
// }            
// }

// }// -->