<?php
    include "loader.inc.php";

    $id = mysqli_real_escape_string($conn,$_GET['id']);

    $error = "";
    $dish_details =  "";
    $image = "";
    $status = "";
    $price = "";

    if($_GET['id']<=0 || $_GET['id']==NULL){
        redirect('dishes');
        die();
    }

    $fetchData = "select * from dish where id='{$id}'";
    $execFetech = mysqli_query($conn, $fetchData);
    $showData = mysqli_fetch_assoc($execFetech);

    if(isset($_POST['submit'])){

        $dish = mysqli_real_escape_string($conn,$_POST['dish']);
        $dish_details = mysqli_real_escape_string($conn,$_POST['dish_details']);
        $category = mysqli_real_escape_string($conn,$_POST['category']);
        $image = mysqli_real_escape_string($conn,$_POST['image']);
        $price = mysqli_real_escape_string($conn,$_POST['price']);
        $alpha = bin2hex(random_bytes(5));
        $new_image = $_FILES['new_image']['name'];
        

        if(isset($new_image)){
        $new_image = strtolower($alpha.$_FILES['new_image']['name']);
        $location = "../uploads/dish/";
        $tempName = $_FILES['new_image']['tmp_name'];
        $extensions = array('image/jpeg', 'image/png', 'image/gif');
        $imgEx = $_FILES['new_image']['type'];
             if(in_array($imgEx,$extensions)==true){
            if(move_uploaded_file($tempName, $location.$new_image)){
               $sql = "update dish set category_id='{$category}',dish='{$dish}',price='{$price}',dish_details='{$dish_details}',image='{$new_image}' where id=$id";
                
                $sql_exec = mysqli_query($conn,$sql);
    
                    if($sql_exec){
                        //unlink('../uploads/dish/'.$image);
                        redirect('dishes');
                        die();
                    }else{
                        $error = alert_info("Error in adding new dish, please try after sometime.");
                    }
            }
            else{
                $error = alert_info("Upload failed");
            }
        }
        else{
            $error = alert_danger("Only JPG, JPEG and PNG are allowed to upload.");
        }


        }else{
            $sql = "update dish set category_id='{$category}',dish='{$dish}',price='{$price}',dish_details='{$dish_details}',image='{$image}' where id=$id";
            
            $sql_exec = mysqli_query($conn,$sql);            
                    if($sql_exec){
                         redirect('dishes');
                         die();
                     }else{
                             $error = alert_info("Error in adding new dish, please try after sometime.");
                    }
        }

       $sql = "update dish set category_id='{$category}',price='{$price}',dish='{$dish}',dish_details='{$dish_details}',image='{$image}' where id=$id";

       $sql_exec = mysqli_query($conn,$sql);
    

       
                    if($sql_exec){
                        redirect('dishes');
                        die();
                    }else{
                        $error = alert_info("Error in adding new dish, please try after sometime.");
                    }
    }

    $sqlCat = "select * from category where status='1' order by category asc";
    $sqlCate = mysqli_query($conn, $sqlCat);

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  'assets/head.php';?>
    <title>Update Dish</title>
  </head>
<body>
<?php include 'assets/navbar.php';?>
<div class="container">
        <div class="row d-flex justify-content-center container-vcenter mb-3">
                <div class="col-md-5">
                <div class="card">
                    <div class="card-body">
                    <h4 class="card-title card-head display-6 text-white text-center rounded py-2 mb-4">
                    Update Dish
                    </h4>
            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']."?id=$id";?>" class="m-2" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Enter Dish Name</label>
                        <input type="text" name="dish" value="<?php echo $showData['dish'];?>" class="form-control" placeholder="Dish Name" required>
                    </div>


                    <div class="form-group">
                        <label>Select Category</label>
                        <select class="form-control" name="category">
                        <option>Select Category</option>
                        <?php
                            while($cat_data=mysqli_fetch_array($sqlCate)){
                            if($showData['category_id']==$cat_data['id']){
                                echo "<option value=".$cat_data['id']." selected>".$cat_data['category']."</option>";
                            }else{
                               echo "<option value=".$cat_data['id'].">".$cat_data['category']."</option>";
                                }   
                            }
                        ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Enter Dish Details</label>
                        <textarea name="dish_details" row="4" class="form-control" placeholder="Enter full details of the dish..." required><?php echo $showData['dish_details'];?></textarea>
                    </div>
                    <div class="form-grou">
                    <label>Price</label>
                    <input name="price" class="form-control" value="<?php echo $showData['price'];?>">
                    </div>
                    <div class="form-group">
                        <label for="order_number">Choose Image</label>
                        <input type="file" class="form-control-file" name="new_image" placeholder="Upload">
                        <input type="hidden" name="image"  value="<?php echo $showData['image'];?>">
                        <img src="<?php echo IMG_UPLOAD_PATH.$showData['image'];?>" style="width:60px;height:auto">
                        <small class="small">Leave Blank if you do not want to change image.</small>
                    </div>
                    
                    <button type="submit" name="submit" class="btn btn-primary btn-md">Save Changes</button>
        </form>

                            <?php echo $error; ?>
                    </div>
                    </div>
                </div>

                </div>

        </div>
    </div>

<?php include 'assets/footer.php';?>
</body>
</html>