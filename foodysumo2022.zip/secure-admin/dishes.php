<?php

include 'loader.inc.php';

$sql = "select dish.*,category.category from dish,category where dish.category_id = category.id";
$sql_exec = mysqli_query($conn, $sql);

if (isset($_GET['id'])) {

    $id = $_GET['id'];

    if ($_GET['status'] == 'inactive' && $id > 0) {
        $updateStatus = "update dish set status='1' where id='{$id}'";
        $runStatus = mysqli_query($conn, $updateStatus);
        if ($runStatus) {
            redirect('dishes');
            die();
        }
    }

    if ($_GET['status'] == 'active' && $id > 0) {
        $updateStatus = "update dish set status='0' where id='{$id}'";
        $runStatus = mysqli_query($conn, $updateStatus);
        if ($runStatus) {
            redirect('dishes');
            die();
        }
    }
}

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  'assets/head.php';?>
    <title>Dishes</title>
  </head>
<body>
<?php include 'assets/navbar.php';?>

<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <div class="cart-title">
                <h4 class="display-4 card-head text-center text-white">ALL Dishes</h4>
            </div>
            <div class="py-3"><a href="add-dish"><button class="btn btn-sm btn-primary">Add Dish</button></a></div>
            <?php if(mysqli_num_rows($sql_exec)>0){
             echo '
						<table id="foodtable" class="table table-striped table-responsive" style="width:100%">
							<thead>
								<tr>
									<th>ID</th>
									<th>Name</th>
									<th>Category</th>
                                    <th>Price</th>
									<th>Description</th>
                                    <th>Image</th>
                                    <th>Status</th>
									<th>ACTION</th>
								</tr>
							</thead>
							<tbody>';
                             while($row = mysqli_fetch_assoc($sql_exec)){                          
                                    
                                echo "<td>".$row['id']."</td>";
                                echo "<td>".$row['dish']."</td>";
                                
                                echo "<td>".$row['category']."</td>";
                                echo "<td>".$row['price']."</td>";
                                echo "<td>".$row['dish_details']."</td>";
                                echo "<td><img src=".IMG_UPLOAD_PATH.$row['image']." alt=".$row['dish']." style='width:60px;height:auto'></td>";
                                if($row[ 'status']==1){ 
                                    echo '<td><a href="dishes?id='.$row[ 'id']. '&status=active"><button type="submit" class="btn btn-success btn-sm" name="status" >Active</button></a></td>'; 
                                     }
                                    else{ 
                                        echo '<td><a href="dishes?id='.$row[ 'id']. '&status=inactive"><button type="submit" class="btn btn-danger btn-sm" name="status" >Inctive</button></a></td>';
                                    }
                                echo '<td><a href="update-dish?id='.$row[ 'id']. '"><button class="btn btn-info btn-sm"><i class="fas fa-pen"></i></button></a></td>';
                                echo '</tr>';
                              } echo '</tbody> </table>'; } /// while close
                    else{ 
                        echo "<h2 class='mb-4 mt-4 text-dark text-center'> No Dish Found</h2>"; 
                        } ?>            
        </div>
    </div>
</div>
<?php include 'assets/footer.php';?>
</body>
</html>