<?php
session_start();
session_regenerate_id();
include "../includes/config.inc.php";
include "../includes/functions.inc.php";
if(isset($_SESSION['username'])){
    redirect('dashboard');
}
$error = "";
$username = $email = "";
if(isset($_POST['submit'])){
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $password = mysqli_real_escape_string($conn,$_POST['password']);
    
    $sql = "select * from admin where email='{$email}'";
    $result = mysqli_query($conn,$sql);

    if(mysqli_num_rows($result)>0){
        while($row=mysqli_fetch_assoc($result)){
            if($row['email']==$email && password_verify($password,$row['password'])){
                $_SESSION['id'] = $row['id'];
                $_SESSION['username'] = $row['username'];
                $_SESSION['name'] = $row['name'];
                redirect('dashboard');
            }
            else{
                $error= alert_info("Please enter a valid email or password..!");
            }
        }
    }else{
        $error= alert_danger("User is not found..!");
    }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  'assets/head.php';?>
    <title>Admin Login</title>
    <style>
        .container{
            margin-top:20vh;
        }
        .card-body h2{
            margin-top:-42px;
            text-transform:uppercase;
            font-weight:600;
            color:#1b1b1b;
            background:#08f;
        }

        .btn-primary{
            background:#08f;;
        }
    </style>
  </head>
<body>
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                    <h2 class="card-title display-6 text-white text-center rounded py-2 mb-4">Admin Login</h2>
                        <form class="mt-2" method="POST" actio="<?php echo htmlentities($_SERVER['PHP_SELF']);?>">
                            <div class="form-group">
                                <label for="email">Enter Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <button type="login" name="submit" class="btn btn-primary">LOGIN</button>
                            </form>
                                <?php 
                                if($error){
                                    echo $error;
                                }
                                ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>