<?php
include "loader.inc.php";

$id = mysqli_real_escape_string($conn,$_GET['id']);

$error="";
$ordernumber= $category="";

if($_GET['id']<=0 || $_GET['id']==NULL){
    redirect('category');
    die();
}

    $fetchData = "select * from category where id='{$id}'";
    $execFetech = mysqli_query($conn, $fetchData);
    $showData = mysqli_fetch_assoc($execFetech);

    if(isset($_POST['submit'])){

        $category = mysqli_real_escape_string($conn,$_POST['category']);
        $ordernumber = mysqli_real_escape_string($conn,$_POST['ordernumber']);

        
        $sql = "update category set category='$category', order_number='$ordernumber' where id='$id' ";
        $exec_in = mysqli_query($conn,$sql);

            if($exec_in){
            redirect('category');
            die();
            }
    
    }




?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  'assets/head.php';?>
    <title>Update Category</title>
  </head>
<body>

<?php include "assets/navbar.php";?>
    <div class="container">
        <div class="row d-flex justify-content-center container-vcenter mb-3">
                <div class="col-md-5">
                <div class="card">
                    <div class="card-body">
                    <h4 class="card-title card-head display-6 text-white text-center rounded py-2 mb-4">Update Category</h4>
                        <form method="POST" action="<?php echo htmlentities($_SERVER['PHP_SELF']."?id=$id");?>" class="m-2">
                            <div class="form-group">
                                <label for="category">Enter Category</label>
                                <input type="text" name="category" class="form-control" id="category" placeholder="Category Type : Indian/Chinese" value="<?php echo $showData['category'];?>" required>
                            </div>

                            <div class="form-group">
                                <label for="order_number">Order Number</label>
                                <input type="number" class="form-control"  name="ordernumber" placeholder="Order Number " value="<?php echo $showData['order_number'];?>"  required>
                            </div>

                            <button type="submit" name="submit" class="btn btn-primary btn-md">Save Changes</button>
                            </form>
                    </div>

                    <div class="container">
                            <?php echo $error; ?>
                    </div>


                    </div>
                </div>

                </div>

        </div>
    </div>

<?php include 'assets/footer.php';?>
</body>
</html>