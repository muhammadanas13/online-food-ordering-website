<?php
include "loader.inc.php";

$error = "";

    if(isset($_POST['submit'])){
        $name = $_POST['name'];
        $mobile = $_POST['mobile'];
        $password = $_POST['password'];
        $cpassword = $_POST['cpassword'];

        $checkMobile = mysqli_query($conn, "select mobile from delivery_boy where mobile='{$mobile}'");

        var_dump($checkMobile);


        if(mysqli_num_rows($checkMobile)==0){
    
            if($password==$cpassword){
                
                $hashPass = password_hash($password, PASSWORD_BCRYPT);
    
                $sql = "insert into delivery_boy(name,mobile,password,status) values('$name','$mobile','$hashPass','1')";
    
                $insertData = mysqli_query($conn,$sql);
    
                if($insertData){
    
                    redirect('delivery-boys');
                    die();
                }
            }
            else{
                $error = alert_info("Please enter same Password!");
            }

        }else{
            $error = alert_danger("Delivery boy already exist!");
        }
    
        
    
            
    }


?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  "assets/head.php";?>
    <title>Add Delivery Boy</title>
  </head>
<body>
<?php include "assets/navbar.php";?>
    <div class="container">
        <div class="row d-flex justify-content-center container-vcenter mb-3">
                <div class="col-md-5">
                <div class="card">
                    <div class="card-body">
                    <h4 class="card-title card-head display-6 text-white text-center rounded py-2 mb-4">Add Delivery Boy</h4>
                        <form method="POST" action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>" class="m-2">
                            <div class="form-group">
                                <label for="name">Enter Full Name</label>
                                <input type="text" name="name" class="form-control" id="name" placeholder="Enter Name" required>
                            </div>

                            <div class="form-group">
                                <label for="mobile">Enter Mobile Number</label>
                                <input type="number" class="form-control" name="mobile"  placeholder="Enter Mobile" required>
                            </div>

                            <div class="form-group">
                                <label for="password">Enter Password</label>
                                <input type="password" class="form-control" id="password"  name="password" placeholder="Enter Password" required>
                            </div>


                            <div class="form-group">
                                <label for="cpassword">Confirm Password</label>
                                <input type="password" class="form-control" id="cpassword"  name="cpassword" placeholder="Confirm Password" required>
                            </div>
                            <button type="submit" name="submit" class="btn btn-primary btn-lg">Add</button>
                            </form>

                            <?php echo $error; ?>
                    </div>
                    </div>
                </div>

                </div>

        </div>
    </div>
<?php include("assets/footer.php");?>
</body>
</html>