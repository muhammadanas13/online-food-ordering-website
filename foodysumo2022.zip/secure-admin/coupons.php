<?php
    include "loader.inc.php";

    $sql = "select * from coupon_code order by id desc";
    $sql_exec = mysqli_query($conn,$sql);
    
    if(isset($_GET['cid'])){
      $cid = $_GET['cid'];
    
        if($_GET['status']=='inactive' && $cid>0){
          $updateStatus = "update coupon_code set status='1' where id=$cid";
          $runStatus = mysqli_query($conn,$updateStatus);
          if($runStatus){
            redirect('coupons');
            die();
          }
        }
    
        if($_GET['status']=='active' && $cid>0){
          $updateStatus = "update coupon_code set status='0' where id=$cid";
          $runStatus = mysqli_query($conn,$updateStatus);
          if($runStatus){
            redirect('coupons');
            die();
          }
        }
    }


?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include  'assets/head.php';?>
    <title>Coupons</title>
  </head>
<body>
<?php include 'assets/navbar.php';?>

<div class="container mt-3">
    <div class="card">
        <div class="card-body">
            <div class="cart-title">
                <h4 class="display-4 card-head text-center text-white">ALL COUPONS</h4>
                <div class="mt-2 mb-2 py-2">
                <a type="button" class="btn btn-primary btn-sm" href="add-coupon-code">
                    Add Coupon
                </a>
                </div>
                <?php
              if(mysqli_num_rows($sql_exec)>0){

                echo '<table id="foodtable" class="table table-striped" style="width:100%">
                  <thead>
                      <tr>
                          <th>ID</th>
                          <th>CODE</th>
                          <th>TYPE</th>
                          <th>VALUE</th>
                          <th>MIN VALUE</th>
                          <th>USER TYPE</th>
                          <th>EXPIRY</th>
                          <th>ADDED ON</th>
                          <th>STATUS</th>
                      </tr>
                  </thead>
                <tbody>';
                  while($row = mysqli_fetch_assoc($sql_exec)){
                      echo '<tr>
                      <td>'.$row['id'].'</td>
                      <td>'.$row['coupon_code'].'</td>';

                      echo '<td>';
                      if($row['coupon_type']=='P'){
                          echo 'PERCENTAGE';
                      }else{
                          echo 'FIXED';
                      }
                      echo '</td>
                      <td>'.$row['coupon_value'].'</td>
                      <td>₹ '.$row['cart_min_value'].'</td>
                      <td>';
                      if($row['user_order']=='O'){
                        echo 'Old User';
                      }else{
                        echo 'New User';
                      }
                      echo '</td>';
                  
                      if($row['expired_on']=='0000-00-00'){
                        echo '<td>Not Set</td>';
                      }else{
                        echo '<td>'.$row['expired_on'].'</td>';

                      }
                      echo '
                      <td>'.$row['added_on'].'</td>';
                      
                        if($row['status']==1){
                          echo '<td><a href="coupons?cid='.$row['id'].'&status=active"><button type="submit" class="btn btn-success btn-sm" name="status" >Active</button></a></td></tr>';
                        }else{
                          echo '<td><a href="coupons?cid='.$row['id'].'&status=inactive"><button type="submit" class="btn btn-danger btn-sm" name="status" >Inactive</button></a></td></tr>';
                        }

                    }//while close
                echo "</tbody></table>";
              
              }// if close
              else{
                echo "NO Data found!";
              }

            ?>
            </div>
        </div>
    </div>
</div>
<?php include 'assets/footer.php';?>
</body>
</html>