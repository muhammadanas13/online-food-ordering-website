<?php

include '../routers.inc.php';

if(isset($_SESSION['r_mobile'])){
    redirect('dashboard');
}
$error = "";
$mobile = "";
if(isset($_POST['submit'])){
    $mobile = mysqli_real_escape_string($conn,$_POST['mobile']);
    $password = mysqli_real_escape_string($conn,$_POST['password']);
    
    $sql = "select * from delivery_boy where mobile='{$mobile}'";

    $result = mysqli_query($conn,$sql);

    if(mysqli_num_rows($result)>0){
        while($row=mysqli_fetch_assoc($result)){
            if($row['status']=='0'){
                    $error= alert_danger("Your account has been deactivated");
                    
            }else{

            if($row['mobile']==$mobile && password_verify($password,$row['password'])){
                $_SESSION['r_id'] = $row['id'];
                $_SESSION['r_name'] = $row['name'];
                $_SESSION['r_mobile'] = $row['mobile'];
                redirect('dashboard');
            }
            else{
                $error= alert_info("Please enter a valid mobile number or password..!");
            }
        }
        }
    }else{
        $error= alert_danger("User is not found..!");
    }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include '../includes/head.php';?>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <title>Rider | Login </title>
  </head>
  <body>
 <div class="container mt-4 mb-2">
        <div class="row d-flex justify-content-center">
            <div class="col-md-4">
                <div class="card vcenter">
                    <div class="card-body">
                    <h2 class="card-title display-6 text-white text-center rounded py-2 mb-4 card-head ">Rider Login</h2>
                        <form class="mt-2" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                            <div class="form-group">
                                <label for="">Enter Mobile Number</label>
                                <input type="number" maxlength=10 class="form-control" name="mobile" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Enter Password</label>
                                <input type="password" class="form-control" name="password" required>
                            </div>
                            <center><button type="login" name="submit" class="btn btn-success bg-ninja">LOGIN</button></center>
                            </form>
                            <div class="container">
                                <?php echo $error ;?>
                            </div>
                            </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
  </body>
</html>