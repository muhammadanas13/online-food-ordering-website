<?php
$error="";
include '../routers.inc.php';
if(!isset($_SESSION['r_mobile'])){
  redirect('index');
  die();
}
$rid = $_SESSION['r_id'];

function pay_mode($pid){
  if($pid==1){
    echo 'COD';
  }elseif($pid==2){
    echo "Prepaid";
  }
}
if(isset($_POST['deliver'])){
  $o_id=$_POST['order_id'];
  $d_status=mysqli_query($conn,"update orders set status=4 where id='$o_id' ");
  if($d_status){
    redirect('dashboard?alert=delivery');
  }
}

if(isset($_POST['accept'])){
  $or_id=$_POST['order_rid'];
  $upd_status=mysqli_query($conn,"update orders set status=3,rider_id='{$rid}' where id='$or_id' ");
  if($upd_status){
    redirect('dashboard?alert=accepted');
  }
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include '../includes/head.php';?>
    <link rel="stylesheet" href="../css/style.css">
    <title>Dashboard | Rider</title>
  </head>
  <body>
 <?php include 'menu.php';?>
 <div class="container mt-2 mb-3">
   
</div>
<hr>
 <div class="container">
  <h2>Order Notifications</h2>
  <?php 
  $tdata = mysqli_query($conn,"select * from orders where rider_id='$rid' and status='3'");
  if(mysqli_num_rows($tdata)>0){
    $row=mysqli_fetch_assoc($tdata);
    echo '<form method="post" action=""><table class="table table-hover">
    <thead>
      <tr class="bg-dark text-white">
        <th>#</th>
        <th>Name</th>
        <th>Payment</th>
        <th>Product Items</th>
        <th>Total  Price</th>
        <th>Address</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>'.$row['id'].'</td>
        <input type="hidden" name="order_id" value="'.$row['id'].'">
        <td>'.$row['name'].'</td>
        <td>';pay_mode($row['method']);echo'</td>
        <td>'.$row['product'].'</td>
        <td>'.$row['address'].'</td>
        <td>'.$row['mobile'].'</td>
        <td><button class="btn btn-success" type="submit" name="deliver">Mark Deliver</button></td>

      </tr>
    </tbody>
  </table></form>';
  
  
  }else{
    $showTable = "select * from orders where status=2";
    $res = mysqli_query($conn,$showTable);
    if(mysqli_num_rows($res)>0){

      echo '<form method="post" action=""><table class="table table-hover">
      <thead>
        <tr class="bg-dark text-white">
          <th>#</th>
          <th>Name</th>
          <th>Payment</th>
          <th>Product Items</th>
          <th>Total  Price</th>
          <th>Address</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>';

        while($tRow = mysqli_fetch_assoc($res)){
          echo '
          <tr>
            <td>'.$tRow['id'].'</td>
            <input type="hidden" value="'.$tRow['id'].'" name="order_rid">
            <td>'.$tRow['name'].'</td>
            <td>';pay_mode($tRow['method']);echo'</td>
            <td>'.$tRow['product'].'</td>
            <td>Rs.'.$tRow['total'].'</td>
            <td>'.$tRow['address'].'</td>
            <td><button class="btn btn-success" type="submit" name="accept">Accept</button></td>
          </tr>
          ';
        }
        
      echo'</tbody>
      </table></form>';
    }else{
      echo "<h2 class='display-4 text-center mt-3'>No Order for delivery!</h2>";
    }
    
  }
  ?>
  
</div>



<?php
if(isset($_GET['alert'])){
    if($_GET['alert']=='accepted'){
    echo alert_info('You accepted the order, reach the restaurant to pick up the order.');
    }
}
if(isset($_GET['alert']) && $_GET['alert']=='delivery'){
  echo alert_success('You have marked the order delivered successfully');
}
?>
<?php include '../includes/footer.php'
?>
    <script src="../js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
  </body>
</html>