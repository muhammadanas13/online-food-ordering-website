<?php
include '../routers.inc.php';
$rider_id = $_SESSION['r_id'];
if(!isset($_SESSION['r_mobile'])){
  redirect('index');
  die();
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include '../includes/head.php';?>
    <link rel="stylesheet" href="../css/style.css">

    <title>Orders | Rider</title>
  </head>
  <body>
 <?php include 'menu.php';?>

 <div class="container mt-3">
 <div class="card">
			<div class="card-body">
				<div class="cart-title">
					<h4 class="display-4 card-head text-center text-white">Order History</h4>
					<div class="container mt-3">
						</div>
						<table id="foodtable" class="table table-striped" style="width:100%">
 <?php
       $sql="select * from orders where rider_id='{$rider_id}' ORDER BY id desc";
       $fetch= mysqli_query($conn,$sql);
       if(mysqli_num_rows($fetch)>0){

        echo '<h2>Order History</h2>          
        <table class="table">
          <thead>
            <tr>
              <th>#ID</th>
              <th>Customer Name</th>
              <th>Dishes</th>
              <th>Payment</th>
              <th>Total</th>
              <th>Address</th>
              <th>Contact</th>
              <th>Status</th>
              <th>Delivery Date</th>
            </tr>
          </thead>
         ';
            while($row=mysqli_fetch_assoc($fetch)){
              echo ' <tbody>
              <tr>
                <td>'.$row['id'].'</td>
                <td>'.$row['name'].'</td>
                <td>'.$row['product'].'</td>
                <td>';
                if($row['method']==1){
                  echo 'COD';
                }else{
                  echo 'Prepaid';
                }

                echo'</td>

                <td>'.$row['total'].'</td>
                <td>'.$row['address'].'</td>
                <td>'.$row['mobile'].'</td>
                <td>';
                
                if($row['status']==1){
                  echo '<button class="btn btn-sm btn-primary" disabled>Preparing</button>';
                }elseif($row['status']==2){
                  echo '<button class="btn btn-sm btn-info" disabled>On the Way</button>';
                }else{
                  echo '<button class="btn btn-sm btn-success" disabled>Delivered</button>';
                }
                
                echo'</td>
                <td>'.$row['date'].'</td>
        
              </tr>
            </tbody>';
            }

        echo '</table>
      </div>';

       }else{
         echo '<div class="text-muted text-center"><img src="../img/cancel.png" class="mb-4"><h2>No Order Found!</h2></div>';
       }


      ?>

			</div>
		</div>
	</div>
  </div></div></div></div></div></div>
<?php include '../includes/footer.php'?>
    <script src="../js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
  </body>
</html>