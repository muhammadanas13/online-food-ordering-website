<div class="header2 bg-success-gradiant">
    <div class="">
        <nav class="navbar navbar-expand-lg h2-nav bg-success-gradiant"> <a class="navbar-brand" href="index"><img src="../img/site-icon.png" style="width:40px;height:auto"></a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#header2" aria-controls="header2" aria-expanded="false" aria-label="Toggle navigation"> <span class="icon-menu"></span> </button>
            <div class="collapse navbar-collapse hover-dropdown" id="header2">
                <ul class="navbar-nav text-right text-white ml-auto">
                    <li class="nav-item active"><a class="nav-link" href="dashboard">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="orders">Delivered Orders</a></li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item text-white"><a class="nav-link" href="logout"><i class="fas fa-power-off"></i> Logout</a></li>
                </ul>
            </div>
        </nav>
    </div>
</div>
<script type="text/javascript">
		setTimeout(function () {
			$('.alert').alert('close');
		}, 4000);
</script>

