<?php

session_start();
session_unset();
unset($_SESSION['mobile']);
session_destroy();
header('location: index');
die();

?>