<?php

    function alert_danger($alertdata){
        $return_alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        .'$alertdata'.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></div>';
         return $return_alert;
    }

    function alert_info($alertdata){
        $return_alert = '<div class="alert alert-info alert-dismissible fade show" role="alert">
        .'$alertdata'.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></div>';
        return $return_alert;
    }

    function alert_success($alertdata){
        $return_alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">
        .'$alertdata'.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></div>';
        return $return_alert;
    }

    function alert_warning($alertdata){
        $return_alert = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
        .'$alertdata'.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></div>';
        return $return_alert;
    }

?>