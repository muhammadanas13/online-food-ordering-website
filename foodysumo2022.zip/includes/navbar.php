<?php

if(isset($_SESSION['cart'])){
    $cartData = count($_SESSION['cart']);
}else{
    $cartData = "0";
}

if(isset($_SESSION['u_name'])){

    echo '<div class="header2 bg-success-gradiant">
    <div class="">
        <nav class="navbar navbar-expand-lg h2-nav bg-success-gradiant"> <a class="navbar-brand" href="index"><img src="img/site-icon.png" style="width:40px;height:auto"></a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#header2" aria-controls="header2" aria-expanded="false" aria-label="Toggle navigation"> <span class="icon-menu"></span> </button>
            <div class="collapse navbar-collapse hover-dropdown" id="header2">
                <ul class="navbar-nav text-right text-white ml-auto">
                    <li class="nav-item active"><a class="nav-link" href="index">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="orders">Order History</a></li>
                    <li class="nav-item"><a class="nav-link" href="transactions">Transactions</a></li>
                    <li class="nav-item"><a class="nav-link" href="shop">Shop</a></li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item text-white"><a class="nav-link" href="cart"><span class="badge badge-info">'.$cartData.'</span><i class="fa fa-shopping-cart ml-2"></i> Cart</a></li>
                    <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      '.$_SESSION['u_name'].'
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                      <a class="dropdown-item" href="signout">Signout</a>
                    </div>
                  </li>
            
                </ul>
            </div>
        </nav>
    </div>
</div>';
}else{
    echo '
    <div class="header2 bg-success-gradiant">
    <div class="">
        <nav class="navbar navbar-expand-lg h2-nav bg-success-gradiant"> <a class="navbar-brand" href="index"><img src="img/site-icon.png" style="width:40px;height:auto"></a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#header2" aria-controls="header2" aria-expanded="false" aria-label="Toggle navigation"> <span class="icon-menu"></span> </button>
            <div class="collapse navbar-collapse hover-dropdown" id="header2">
                <ul class="navbar-nav text-right text-white ml-auto">
                    <li class="nav-item active"><a class="nav-link" href="index">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="shop">Shop</a></li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active"><a class="nav-link" href="signin">Signin</a></li>
                    <li class="nav-item"><a class="btn rounded-pill btn-dark mx-1 py-2 px-4" href="signup">Sign up</a></li>
                    <li class="nav-item text-white"><a class="nav-link" href="cart"><i class="fa fa-shopping-cart ml-2"></i> Cart <span class="badge badge-primary" style="margin-left:-4px">'.$cartData.'</span></a></li>
                </ul>
            </div>
        </nav>
    </div>
</div>';

}?>
