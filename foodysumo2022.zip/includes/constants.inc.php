<?php

define('SITE_NAME','FoodySUMO');
define('HOST','/food');
define('IMG_UPLOAD_PATH',"/food/uploads/dish/");

?>