<?php

function redirect($path){
    $process_path = header('location: '.$path.'');
    return $process_path;
}

function alert_danger($alertdata){
    $return_alert = '<div class="alert alert-danger alert-dismissible fade show mt-2 mb-2" role="alert">'.$alertdata.'
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>';
     return $return_alert;
}

function alert_success($alertdata){
    $return_alert = '<div class="alert alert-success alert-dismissible fade show mt-2 mb-2" role="alert">'.$alertdata.'
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>';
     return $return_alert;
}

function alert_info($alertdata){
    $return_alert = '<div class="alert alert-info alert-dismissible fade show mt-2 mb-2" role="alert">'.$alertdata.'
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>';
     return $return_alert;
}

function sms_alert($numberData,$messageData, $otpData){

  $message = $messageData.' : '.$otpData;
  $userNumber = $numberData;
  
  // Replace yourapi_tokenGoesHere with your API Key for api visit ---> fast2SMS.com


  $curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2?authorization=yourapi_tokenGoesHere&message=".urlencode(''.$message.'')."&language=english&route=q&numbers=".urlencode($userNumber),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => array(
      "cache-control: no-cache"
    ),
  )); 
  $response = curl_exec($curl);
  $err = curl_error($curl);
  curl_close($curl);

  if ($err) {
    $responseData = 0 ;
  } else {
    $responseData = 1;
  }

  return $responseData;

}


$token = bin2hex(random_bytes(16));

include('smtp/PHPMailerAutoload.php');

function smtp_mailer($to,$subject, $msg){

	$mail = new PHPMailer(); 
	// $mail->SMTPDebug=3;
	$mail->IsSMTP(); 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'TLS'; 
	$mail->Host = "smtp.ionos.com"; // your host example: smtp.gmail.com 
	$mail->Port = "587"; 
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	$mail->Username = ""; // enter email@domain.com
	$mail->Password = 'wRB,YC_PHIh[%;O2ko'; //  enter password
	$mail->SetFrom("email@domain.com"); // enter email@domain.com
	$mail->Subject = $subject;
	$mail->Body =$msg;
	$mail->AddAddress($to);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));

	if(!$mail->Send()){
		// echo $mail->ErrorInfo;
    $mailData = false ;
	}else{
		// echo 'Sent';
    $mailData = true;
	}

  return $mailData;
}



?>