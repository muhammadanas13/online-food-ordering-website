<?php

$host = "localhost";
$username = "root";
$password = ""; //s?QuP7a}3VvlRRcM&s
$database ="food";

$conn = mysqli_connect($host,$username,$password,$database);

if(!$conn){
   echo mysqli_connect_error(); 
   die();
}

?>