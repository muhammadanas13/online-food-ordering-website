<?php
include 'routers.inc.php';
if(!isset($_SESSION['tnx_id'])){
    redirect('index');
}
    $tnx_id = $_GET['payment_id'];
    $pr_id = $_GET['payment_request_id'];
    $status = $_GET['payment_status'];

if($status=='Credit'){
    
    $update = mysqli_query($conn,"update transaction set payment_id='{$tnx_id}',payment_status='successful' where payment_request_id = '{$pr_id}'");
    $uid = $_SESSION['id'];
    $updateOrder = mysqli_query($conn,"update orders set status=0 where user_id='{$uid}' ORDER BY id desc limit 1");
    redirect('orders?alert=success');
    unset($_SESSION['tnx_id']);
    unset($_SESSION['cart']);
    unset($_SESSION['total']);
}else{
    redirect('checkout?payment=failed');
}

?>