<?php

include 'routers.inc.php';

if(isset($_SESSION['u_name'])){
    redirect('orders');
}

$error = "";
$username = $email = "";
if(isset($_POST['submit'])){
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $password = mysqli_real_escape_string($conn,$_POST['password']);
    
    $sql = "select * from users where email='{$email}'";

    $result = mysqli_query($conn,$sql);

    if(mysqli_num_rows($result)>0){
        while($row=mysqli_fetch_assoc($result)){
            if($row['status']=='0'){
                $error = alert_danger("Your account has been deactivated");
            }else{
            if($row['email']==$email && password_verify($password,$row['password'])){
                $_SESSION['u_id'] = $row['id'];
                $_SESSION['u_name'] = $row['name'];
                if(isset($_GET['redirect'])=='checkout'){
                    redirect('checkout');
                }else{
                    redirect('orders');
                }
                
                
            }
            else{
                $error= alert_info("Please enter a valid email or password..!");
            }
        }
    }
    }else{
        $error= alert_danger("User is not found..!");
    }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'includes/head.php';?>

    <title>Signin | FoodySumo.com</title>
  </head>
  <body>
 <?php include 'includes/navbar.php';?>

 <div class="container mt-4 mb-2">
        <div class="row d-flex justify-content-center">
            <div class="col-md-4">
                <div class="card vcenter">
                    <div class="card-body">
                    <h2 class="card-title display-6 text-white text-center rounded py-2 mb-4 card-head ">Login</h2>
                        <form class="mt-2" method="POST" action="">
                            <div class="form-group">
                                <label for="email">Enter Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" name="password" required>
                            </div>
                            <center><button type="login" name="submit" class="btn btn-success bg-ninja">LOGIN</button>

                            <p class="text-muted text-center mt-4">Do not have account? <a href="signup" class="btn btn-info"> Create Account</a></p>
                        </center>
                            </form>

                            <div class="container">
                                <?php echo $error;?>
                            </div>
                            </div>
                </div>
            </div>
        </div>
    </div>

<?php include 'includes/footer.php'?>
    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>