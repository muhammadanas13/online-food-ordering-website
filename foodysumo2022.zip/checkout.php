<?php
include 'routers.inc.php';
$error = "";
$total=0;
$grand_total=0;
$product=$quantity=$prices=null;
$user_id=null;
if(!isset($_SESSION['cart'])){
  redirect('shop');
}

if(isset($_SESSION['u_name'])){
  $user_id = $_SESSION['u_id'];
}

$fetchAddress = mysqli_query($conn,"select * from address where user_id='{$user_id}'");

if(isset($_POST['checkout'])){
  $fetchUserData = mysqli_query($conn,"select * from users where id='{$user_id}'");
  $showUserData = mysqli_fetch_assoc($fetchUserData);
  $email = $showUserData['email'];
  $name = $showUserData['name'];
  $mobile = $showUserData['mobile'];
  $payment_mode = mysqli_real_escape_string($conn,$_POST['mode']);
  $address = $_POST['address'];
  
  //$address = $_POST['pickaddress'];
  $total=0;
  foreach($_SESSION['cart'] as $k => $pro){

    $product .= $pro['dish'] . ","; 
    $quantity .= $pro['qty'] . ","; 
    $prices .= $pro['price'] . ",";
    $pro['price']*$pro['qty'];
    $total = $total + $pro['price']*$pro['qty'];

  
  }


  if($payment_mode==1){

    $insert = "INSERT INTO `orders` (`user_id`, `rider_id`, `name`, `email`, `mobile`, `method`, `quantity`, `product`, `address`,`prices`, `total`, `discount`, `date`, `status`) VALUES ('$user_id', '0', '$name', '$email', '$mobile', '$payment_mode', '$quantity', '$product', '$address', '$prices','$total', '$discount', current_timestamp(), '1')";

    $run_insert = mysqli_query($conn,$insert);

   if($run_insert){
     unset($_SESSION['cart']);
     unset($_SESSION['total']);
     redirect('orders?alert=success');
    die();
   }

  }elseif($payment_mode==2){
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, 'https://test.instamojo.com/api/1.1/payment-requests/');
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER,
                array("X-Api-Key:test_00b11184b29fcdc1f9ba49565bc",
                      "X-Auth-Token:test_80f681f2633b510d93d319ba833"));
    $payload = Array(
        'purpose' => 'Pay at FoodySumo',
        'amount' => $_SESSION['total'],
        'phone' => $mobile,
        'buyer_name' => $name,
        'redirect_url' => 'http://localhost/food/redirect',
        'send_email' => true,
        'send_sms' => true,
        'email' => $email,
        'allow_repeated_payments' => false
    );
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
    $response = curl_exec($ch);
    curl_close($ch); 
    $response = json_decode($response);
    $_SESSION['tnx_id'] = $response->payment_request->id;
    $tnx_id = $_SESSION['tnx_id'];
    $pinsert = mysqli_query($conn,"INSERT INTO `transaction` (`user_id`, `payment_id`, `payment_request_id`, `payment_status`) VALUES ('$user_id', 'null', '$tnx_id', 'pending');");

    if($pinsert){

      $insert = "INSERT INTO `orders` (`user_id`, `rider_id`, `name`, `email`, `mobile`, `method`, `quantity`, `product`, `address`,`prices`, `total`, `discount`, `date`, `status`) VALUES ('$user_id', '0', '$name', '$email', '$mobile', '$payment_mode', '$quantity', '$product', '$address', '$prices','$total', '$discount', current_timestamp(), '0')";

      $run_insert = mysqli_query($conn,$insert);

    redirect($response->payment_request->longurl);
    die();
    }
  }
  
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'includes/head.php';?>
    <title>Checkout | FoodySumo.com</title>
    <style>



    </style>
  </head>
  <body>
 <?php include 'includes/navbar.php';?>
 
 
 <?php if(isset($_SESSION['cart'])){?>

 <div class="container mt-4">
     <div class="row">

     <div class="col-md-8">
     <table class="table table-striped" style="width:100%">
    <thead class="thead-dark">
      <tr>
        <th>#</th>
        <th>Image</th>
        <th>Name</th>
        <th>Quantity</th>
        <th>Price</th>
      </tr>
    </thead>
    <tbody>
    
    <?php
    $i=1;
    foreach($_SESSION['cart'] as $k => $item){?>

      <tr>
        <td><?php echo $i; $i++;?></td>
        <td><img src="uploads/dish/<?php echo $item['img'];?>" style="width:64px;height:auto"></td>
        <td><?php echo $item['dish']; ?></td>
        <td><?php echo $item['qty']; ?></td>
        <td>₹<?php echo $item['price']*$item['qty'];
            $total = $total + $item['price']*$item['qty'];
        ?></td>
      </tr>
    

      <?php }?>
    </tbody>
    </table>
    </div>
    <div class="col-md-4">
        <div class="card">
        <div class="card-body">
            <div class="card-head p-2 rounded text-white text-center">
            <h5 class="card-title">Checkout</h5>
            </div>
            
            <form action="" method="post">
            <p class="mt-2 mb-2">Number of Items : <?php echo $i-1;?></p>
            <p class="mt-2 mb-2">Taxes + GST : <?php echo '₹'. $tax = 18 *  $total/100;  ?></p>
            <p><strong>Grand Total : ₹<?php echo $_SESSION['total'] = $grand_total = $total+$tax;?></strong></p>

            <input type="radio" checked="checked" name="mode" value="1">
            <label>COD</label><br>
            <input type="radio" name="mode" value="2">
            <label>Pay Online</label><br>
            <?php
                if(isset( $_SESSION['u_name'])){
                    
                    echo '<button class="btn btn-primary" name="checkout" type="submit">Checkout</button>';
            }
            
              else{
                echo '<p>Login to checkout</p>
                <a href="signin?redirect=checkout" class="btn btn-md btn-success">Login Now</a>';
              }      

            ?>
            
        </div>
     </div>
    </div>
</div>
<?php if(isset($_SESSION['u_name'])){?>

<div class="col-md-8 mt-5">
  <div class="card">
    <div class="card-body">
      <div class="card-head p-2 rounded text-white text-center">
          <h5 class="card-title">Your Addresses</h5>
      </div>
      <?php while($showAddress = mysqli_fetch_assoc($fetchAddress)){

        $pickaddress = "Address : ".$showAddress['address']." , City : ".$showAddress['city'].", Pincode : ".$showAddress['pincode']." , State : ".$showAddress['state'].", Landmark : ".$showAddress['landmark'];
        echo '
        <table class="table table-hover mt-3">
        <tr class="mb-3">
        <td><input type="radio" name="address" value="'.$pickaddress.'" required></td>
        <td><p>'.$pickaddress.'</p> </td>
        </tr> 
        </table>
          '
        ;
        }

        ?>

    </div>
  </div>
</div>
<?php } ?>

</div>

</form>
<?php }?>

<?php include 'includes/footer.php'?>
<?php
if(isset($_GET['payment'])=='failed'){
  echo alert_danger("Transaction Failed, Please try after sometime");
}
?>
    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>