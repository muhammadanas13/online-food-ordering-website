<?php
 include 'routers.inc.php';
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'includes/head.php';?>
    <link rel="stylesheet" href="css/style.css">

    <title>FoodySumo</title>
  </head>
  <body>
 <?php include 'includes/navbar.php';?>
 <div class="header-banner">
     <div class="container text-center py-4">
         <h1 class="display-4 text-white py-3">Welcome to Foody Sumo</h1>
         <h2><small>Order Now</small></h2>
         <p class="text-white">Think, Choose, Order, Delivered , Eat, Enjoy and Repeat.</p>
         <a class="btn btn-lg rounded-pill bg- mx-1 bg-success text-white py-2 px-4" href="shop">Go to Shop</a>
     </div>
 </div>
<div class="container mt-5">
    <div class="row">
        <div class="col-4">
            <div class="sumo-delivery">
                <center><img src="img/delivery.png"></center>
                <h2>Lighting-Fast Delivery</h2>
                <p class="text-center text-muted"><small>Want a delicious meal, but no time we will deliver it hot and yummy.</small></p>
            </div>
        </div>

        <div class="col-4">
            <div class="sumo-delivery">
                <center><img src="img/minimum.png"></center>
                <h2>No Minimum Order Required</h2>
                <p class="text-center text-muted"><small>Order for yourself or for the group, with no restrictions on order value.</small></p>
            </div>
        </div>


        <div class="col-4">
            <div class="sumo-delivery">
                <center><img src="img/fresh.png"></center>
                <h2>Fresh Food</h2>
                <p class="text-center text-muted"><small>Freshness and tasty food delivered at your doorstep.</small></p>
            </div>
        </div>
    </div> 
</div>
<?php
if(isset($_GET['alert'])=='verify-email'){
    echo alert_info('<strong>Verify Email : </strong>We sent an email to your email account.');
}elseif(isset($_GET['alert'])=='account-created'){
    echo alert_success('Your account has been created successfully');
}
?> 
<?php include 'includes/footer.php'?>
    <!-- Optional JavaScript -->
    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>