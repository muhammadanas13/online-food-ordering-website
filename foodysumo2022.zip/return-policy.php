<?php

include 'routers.inc.php';

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'includes/head.php';?>

    <title>Return Policy | FoodySumo.com</title>
  </head>
  <body>
 <?php include 'includes/navbar.php';?>
<div class="container">
<h1>Return Policy</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus saepe ea voluptates quos molestias error quisquam eum tempora, aut esse sunt, laborum placeat!</p>
</div>
<?php include 'includes/footer.php'?>
    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>