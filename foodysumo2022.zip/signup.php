<?php

include 'routers.inc.php';

$error = "";

if(isset($_POST['submit'])){
    
    $name = mysqli_real_escape_string($conn,$_POST['name']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $mobile = mysqli_real_escape_string($conn,$_POST['mobile']);
    $password = mysqli_real_escape_string($conn,$_POST['password']);
    $cpassword = mysqli_real_escape_string($conn,$_POST['cpassword']);
    
    $hashpass = password_hash($password, PASSWORD_BCRYPT);
    
    $token = bin2hex(random_bytes(16));
    
    $checkemail = "select * from users where email ='$email' ";
    
    $emailquery = mysqli_query($conn,$checkemail);
    
    $emailcount = mysqli_num_rows($emailquery);
    
    if($emailcount>0){
        $error = alert_danger("User already exists!");
    }
    else{
        if($password===$cpassword){
           $otp = mt_rand(100000,999999);
            $insertquery ="insert into users(name,email,mobile,password,token,sms_otp,status) values ('$name','$email','$mobile','$hashpass','$token','$otp','-1')"; 
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                
                $runinsert=mysqli_query($conn,$insertquery);

                if($runinsert){
                    
                    $msg = '<html>
                    <head>
                    </head>
                    <body>
                    Hello,<br><br>
                    Click on the email verification link to verify your account.<br>
                    <a href="http://localhost/food/verify-account?token='.$token.'"> Verify Account</a>
                    <br>
                    Thanks
                    </body>
                    </html>';

                    $mailSentInfo = smtp_mailer($email,"Account Verification", $msg);
                            
                    if($mailSentInfo){
                        
                        $smsChecker = sms_alert($mobile,"OTP for FoodySumo ",$otp);

                        if($smsChecker){
                            $_SESSION['u_email'] = $email;
                            $_SESSION['u_mobile']= $mobile;
                            $_SESSION['otp'] = $otp;    
                            redirect('step-2'); 
                            die();

                        }

                    }

                    
                }

              } else {
                 $error = alert_danger("Email is not valid.!");
              }

        }
        else{
            $error = alert_info("Your password has not matched with Confirm Password.");
        }
    }
    
    
    }
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'includes/head.php';?>

    <title>Signup | FoodySumo.com</title>
  </head>
  <body>
 <?php include 'includes/navbar.php';?>

 <div class="container container-vcenter">
        <div class="row d-flex justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                    <h2 class="card-title display-6 text-white text-center rounded py-2 mb-4 card-head">Sign Up</h2>
                        <form class="mt-2" method="POST" action="<?php echo $_SERVER['PHP_SELF'];?>" autocomplete="off">
                            <div class="form-group">
                                <label for="name">Enter Full Name</label>
                                <input type="text" class="form-control" name="name" placeholder="Your Full Name" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Enter Email</label>
                                <input type="email" class="form-control" name="email"  placeholder="YourEmail@gmail.com" required>
                            </div>
                            <div class="form-group">
                                <label >Enter Mobile Number</label>
                                <input type="number" minlength="10" maxlength="10" class="form-control" placeholder="9876543210" name="mobile" required>
                            </div>
                            <div class="form-group">
                                <label>Enter Password</label>
                                <input type="password" class="form-control"  name="password" placeholder="Password" minlength="6" autocomplete="off" required>
                            </div>
                            <div class="form-group">
                                <label>Confirm Password</label>
                                <input type="password"  minlength="6" autocomplete="off" class="form-control" placeholder="Confirm Password" name="cpassword" required>
                            </div>
                            <center><button type="submit" name="submit" class="btn btn-success bg-ninja  text-center">Signup</button>
                            <p class="text-muted text-center mt-4">Already have account? <a href="signin" class="btn btn-info"> SignIn</a></p>
                        </center>
                            </form>
                            </div>
                            <div class="container"><?php echo $error;?></div>
                            
                </div>
            </div>
        </div>
    </div>

<?php include 'includes/footer.php'?>
    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>